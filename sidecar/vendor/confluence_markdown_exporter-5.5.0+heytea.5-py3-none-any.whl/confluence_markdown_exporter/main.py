import json
import logging
import os
import platform
import sys
import urllib.parse
from typing import Annotated

import typer
import typer.rich_utils
import yaml
from rich.panel import Panel
from rich.table import Table

from confluence_markdown_exporter import __version__
from confluence_markdown_exporter import config as config_module
from confluence_markdown_exporter.utils.app_data_store import APP_CONFIG_PATH
from confluence_markdown_exporter.utils.app_data_store import get_settings
from confluence_markdown_exporter.utils.lockfile import LockfileManager
from confluence_markdown_exporter.utils.measure_time import measure
from confluence_markdown_exporter.utils.rich_console import console
from confluence_markdown_exporter.utils.rich_console import get_rich_console
from confluence_markdown_exporter.utils.rich_console import get_stats
from confluence_markdown_exporter.utils.rich_console import reset_stats
from confluence_markdown_exporter.utils.rich_console import setup_logging

typer.rich_utils._get_rich_console = get_rich_console

logger = logging.getLogger(__name__)


def _is_interactive() -> bool:
    """Whether cme may open the interactive config menu.

    Off when CME_NON_INTERACTIVE is set, when CI is set, or when stdin is not a
    terminal, so wrappers and CI jobs get an error instead of a blocking prompt.
    """
    if os.environ.get("CME_NON_INTERACTIVE", "").strip().lower() in {"1", "true", "yes"}:
        return False
    if os.environ.get("CI"):
        return False
    return sys.stdin is not None and sys.stdin.isatty()


class _CmeTyper(typer.Typer):
    """Typer subclass that intercepts AuthNotConfiguredError at the app boundary.

    When an export command raises AuthNotConfiguredError, the exception propagates
    through any active console.status() context managers (stopping spinners cleanly
    via their __exit__) before reaching here.  We then open the config menu at the
    exact failing URL and exit — no traceback, no per-command boilerplate.
    """

    def __call__(self, *args: object, **kwargs: object) -> None:
        from confluence_markdown_exporter.api_clients import AuthNotConfiguredError

        try:
            super().__call__(*args, **kwargs)
        except AuthNotConfiguredError as e:
            if not _is_interactive():
                hint = (
                    " Or disable Jira enrichment with "
                    "`cme config set export.enable_jira_enrichment=false`."
                    if e.service == "Jira"
                    else ""
                )
                print(  # noqa: T201
                    f"Error: {e.service} credentials for {e.url} are missing or invalid. "
                    f"Configure them with `cme config edit auth.{e.service.lower()}`.{hint}",
                    file=sys.stderr,
                )
                sys.exit(1)

            from confluence_markdown_exporter.utils.config_interactive import main_config_menu_loop

            console.print(
                f"Please configure {e.service} credentials for {e.url} and re-run the export."
            )
            main_config_menu_loop(f"auth.{e.service.lower()}", new_instance_url=e.url)
            sys.exit(1)
        except ValueError as e:
            console.print(
                f"[red bold]{e}[/red bold]\n"
                "See [code]--help[/code] or [code]README.md[/code] for more information."
            )
            sys.exit(1)


# Each list item must be its own \n\n-separated block so typer's epilog renderer
# keeps single \n between items, forming a valid markdown bullet list.
_QUICKSTART_EPILOG = (
    "**Quick start:**\n\n"
    "- Configure credentials: `cme config edit auth.confluence`\n\n"
    "- Set output path: `cme config set export.output_path=./output`\n\n"
    "- Export a page: `cme pages https://company.atlassian.net/wiki/spaces/KEY/pages/123/Title`\n\n"
    "- Export a space: `cme spaces https://company.atlassian.net/wiki/spaces/MYSPACE`\n\n"
    "- Export everything: `cme orgs https://company.atlassian.net`\n\n"
    "- Each command also has a singular alias"
    " (`page`, `folder`, `space`, `org`) that behaves identically.\n\n"
)

_PAGE_URL_FORMATS = (
    "**Supported URL formats:**\n\n"
    "- **Cloud**: `https://company.atlassian.net/wiki/spaces/KEY/pages/123/Title`\n\n"
    "- **Server (long)**: `https://confluence.company.com/display/KEY/Title`\n\n"
    "- **Server (short)**: `https://confluence.company.com/KEY/Title`\n\n"
)

_SPACE_URL_FORMATS = (
    "**Supported URL formats:**\n\n"
    "- **Cloud**: `https://company.atlassian.net/wiki/spaces/SPACEKEY`\n\n"
    "- **Server (long)**: `https://confluence.company.com/display/SPACEKEY`\n\n"
    "- **Server (short)**: `https://confluence.company.com/SPACEKEY`\n\n"
)

app = _CmeTyper(
    rich_markup_mode="markdown",
    no_args_is_help=True,
    help=(
        "Export Confluence pages, spaces, or entire organizations to Markdown files.\n\n"
        "Authentication and settings are managed via `cme config`. "
        "Run `cme config` to open the interactive menu, or use "
        "`cme config set <key=value>` to set values directly.\n\n"
        "Most settings can also be overridden with environment variables using the prefix "
        "`CME_` and `__` as the nested delimiter "
        "(e.g. `CME_EXPORT__OUTPUT_PATH=/tmp/export`)."
    ),
    epilog=_QUICKSTART_EPILOG,
)
app.add_typer(config_module.app, name="config")


def _init_logging() -> None:
    """Initialize logging from config (CME_EXPORT__LOG_LEVEL env var takes precedence)."""
    export = get_settings().export
    log_file = APP_CONFIG_PATH.parent / "cme.log" if export.save_log_to_file else None
    setup_logging(export.log_level, log_file=log_file)


def _print_summary() -> None:
    """Print a rich summary panel with export statistics."""
    stats = get_stats()
    if stats.total == 0:
        return

    output_path = get_settings().export.output_path

    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="dim", justify="right")
    grid.add_column()

    grid.add_row("Pages", "")
    grid.add_row("  Total", str(stats.total))
    grid.add_row("  [success]Exported[/success]", f"[success]{stats.exported}[/success]")
    grid.add_row("  [dim]Skipped (unchanged)[/dim]", str(stats.skipped))
    if stats.removed:
        grid.add_row("  [dim]Removed[/dim]", str(stats.removed))
    if stats.failed:
        grid.add_row("  [error]Failed[/error]", f"[error]{stats.failed}[/error]")

    attachments_total = (
        stats.attachments_exported + stats.attachments_skipped + stats.attachments_failed
    )
    if attachments_total or stats.attachments_removed:
        grid.add_row("Attachments", "")
        if attachments_total:
            grid.add_row("  Total", str(attachments_total))
        att_exp = stats.attachments_exported
        grid.add_row("  [success]Exported[/success]", f"[success]{att_exp}[/success]")
        grid.add_row("  [dim]Skipped (unchanged)[/dim]", str(stats.attachments_skipped))
        if stats.attachments_removed:
            grid.add_row("  [dim]Removed[/dim]", str(stats.attachments_removed))
        if stats.attachments_failed:
            grid.add_row("  [error]Failed[/error]", f"[error]{stats.attachments_failed}[/error]")

    grid.add_row("Output", str(output_path))

    if stats.failed:
        title = "[warning]Export finished with errors[/warning]"
    else:
        title = "[success]Export complete[/success]"
    console.print(Panel(grid, title=title, expand=False))


@app.command(
    help=(
        "Export one or more Confluence pages by URL to Markdown.\n\n"
        "Fetches each page via the Confluence API and writes a Markdown file to the "
        "configured output directory (`export.output_path`). "
        "Pages that have not changed since the last export are skipped by default "
        "(`export.skip_unchanged=true`)."
    ),
    epilog=(
        "**Examples:**\n\n"
        "- `cme pages https://company.atlassian.net/wiki/spaces/KEY/pages/123/My+Page`\n\n"
        "- `cme pages https://...page1 https://...page2` — export multiple pages at once\n\n"
        "- `cme page URL` — singular alias, identical behaviour\n\n"
        "---\n\n" + _PAGE_URL_FORMATS
    ),
)
def pages(
    page_urls: Annotated[
        list[str],
        typer.Argument(
            help=(
                "One or more Confluence page URLs. "
                "Supports Cloud and Server URL formats. "
                "Example: https://company.atlassian.net/wiki/spaces/KEY/pages/123/Title"
            ),
            metavar="PAGE_URL",
        ),
    ],
) -> None:
    from confluence_markdown_exporter.confluence import Page
    from confluence_markdown_exporter.confluence import sync_removed_pages
    from confluence_markdown_exporter.utils.page_registry import PageTitleRegistry

    _init_logging()
    stats = reset_stats(total=len(page_urls))
    with measure(f"Export pages {', '.join(page_urls)}"):
        LockfileManager.init()

        exported_urls: set[str] = set()
        fetched_pages: list[Page] = []
        for page_url in page_urls:
            with console.status(f"[dim]Fetching [highlight]{page_url}[/highlight]…[/dim]"):
                page = Page.from_url(page_url)
            PageTitleRegistry.register(int(page.id), page.title)
            fetched_pages.append(page)

        for page in fetched_pages:
            LockfileManager.mark_seen([page.id])
            if not LockfileManager.should_export(page):
                stats.inc_skipped()
                exported_urls.add(page.base_url)
                continue
            try:
                with console.status(f"[dim]Exporting [highlight]{page.title}[/highlight]…[/dim]"):
                    attachment_entries = page.export()
                LockfileManager.record_page(page, attachment_entries)
                stats.inc_exported()
            except Exception:
                logger.exception("Failed to export page %s", page.title)
                stats.inc_failed()
            exported_urls.add(page.base_url)

        for base_url in exported_urls:
            sync_removed_pages(base_url)

    _print_summary()


app.command(
    name="page",
    help=(
        "Alias for `pages`. Export one or more Confluence pages by URL to Markdown.\n\n"
        "See `cme pages --help` for full documentation and all supported URL formats."
    ),
    epilog=(
        "**Example:**\n\n"
        "- `cme page https://company.atlassian.net/wiki/spaces/KEY/pages/123/My+Page`\n\n"
    ),
)(pages)


@app.command(
    help=(
        "Export one or more Confluence pages **and all their descendants** by URL to Markdown.\n\n"
        "Recursively fetches the given page(s) and every child page beneath them, "
        "then writes Markdown files to the configured output directory. "
        "Useful for exporting entire page trees without exporting a whole space."
    ),
    epilog=(
        "**Examples:**\n\n"
        "- `cme pages-with-descendants https://company.atlassian.net/wiki/spaces/KEY/pages/123/Root`\n\n"
        "- `cme pages-with-descendants https://...root1 https://...root2` — multiple trees\n\n"
        "- `cme page-with-descendants URL` — singular alias, identical behaviour\n\n"
        "---\n\n" + _PAGE_URL_FORMATS
    ),
)
def pages_with_descendants(
    page_urls: Annotated[
        list[str],
        typer.Argument(
            help=(
                "One or more Confluence page URLs. "
                "Each page and all its descendants will be exported. "
                "Example: https://company.atlassian.net/wiki/spaces/KEY/pages/123/Title"
            ),
            metavar="PAGE_URL",
        ),
    ],
) -> None:
    from confluence_markdown_exporter.confluence import Page
    from confluence_markdown_exporter.confluence import sync_removed_pages

    _init_logging()
    with measure(f"Export pages {', '.join(page_urls)} with descendants"):
        LockfileManager.init()

        exported_urls: set[str] = set()
        for page_url in page_urls:
            page = Page.from_url(page_url)
            page.export_with_descendants()
            exported_urls.add(page.base_url)

        for base_url in exported_urls:
            sync_removed_pages(base_url)

    _print_summary()


app.command(
    name="page-with-descendants",
    help=(
        "Alias for `pages-with-descendants`. "
        "Export a Confluence page and all its descendants by URL to Markdown.\n\n"
        "See `cme pages-with-descendants --help` for full documentation."
    ),
    epilog=(
        "**Example:**\n\n"
        "- `cme page-with-descendants https://company.atlassian.net/wiki/spaces/KEY/pages/123/Root`\n\n"
    ),
)(pages_with_descendants)


@app.command(
    help=(
        "Export all pages in one or more Confluence Cloud **folders** by URL to Markdown.\n\n"
        "Exports every page beneath each folder, including pages in nested folders."
    ),
    epilog=(
        "**Examples:**\n\n"
        "- `cme folders https://company.atlassian.net/wiki/spaces/KEY/folder/123`\n\n"
        "- `cme folders https://...folder1 https://...folder2` — export multiple folders\n\n"
        "- `cme folder URL` — singular alias, identical behaviour\n\n"
    ),
)
def folders(
    folder_urls: Annotated[
        list[str],
        typer.Argument(
            help=(
                "One or more Confluence folder URLs. "
                "Example: https://company.atlassian.net/wiki/spaces/KEY/folder/123"
            ),
            metavar="FOLDER_URL",
        ),
    ],
) -> None:
    from confluence_markdown_exporter.confluence import Folder
    from confluence_markdown_exporter.confluence import sync_removed_pages

    _init_logging()
    with measure(f"Export folders {', '.join(folder_urls)}"):
        LockfileManager.init()

        exported_urls: set[str] = set()
        for folder_url in folder_urls:
            folder = Folder.from_url(folder_url)
            folder.export()
            exported_urls.add(folder.base_url)

        for base_url in exported_urls:
            sync_removed_pages(base_url)

    _print_summary()


app.command(
    name="folder",
    help=(
        "Alias for `folders`. Export all pages in a Confluence folder by URL to Markdown.\n\n"
        "See `cme folders --help` for full documentation."
    ),
    epilog=(
        "**Example:**\n\n- `cme folder https://company.atlassian.net/wiki/spaces/KEY/folder/123`\n\n"
    ),
)(folders)


@app.command(
    help=(
        "Export **all pages** in one or more Confluence spaces by URL to Markdown.\n\n"
        "Fetches the homepage of each space and every page beneath it via the Confluence API "
        "and writes Markdown files to the configured output directory. "
        "Set `export.only_homepage_descendants=false` to also export pages outside the "
        "homepage tree. "
        "Pages that have not changed since the last export are skipped by default."
    ),
    epilog=(
        "**Examples:**\n\n"
        "- `cme spaces https://company.atlassian.net/wiki/spaces/MYSPACE`\n\n"
        "- `cme spaces https://...SPACE1 https://...SPACE2` — export multiple spaces\n\n"
        "- `cme space URL` — singular alias, identical behaviour\n\n"
        "---\n\n" + _SPACE_URL_FORMATS
    ),
)
def spaces(
    space_urls: Annotated[
        list[str],
        typer.Argument(
            help=(
                "One or more Confluence space URLs. "
                "All pages within each space will be exported. "
                "Example: https://company.atlassian.net/wiki/spaces/MYSPACE"
            ),
            metavar="SPACE_URL",
        ),
    ],
) -> None:
    from confluence_markdown_exporter.confluence import Space
    from confluence_markdown_exporter.confluence import sync_removed_pages

    _init_logging()
    with measure(f"Export spaces {', '.join(space_urls)}"):
        LockfileManager.init()

        exported_urls: set[str] = set()
        for space_url in space_urls:
            space = Space.from_url(space_url)
            space.export()
            exported_urls.add(space.base_url)

        for base_url in exported_urls:
            sync_removed_pages(base_url)

    _print_summary()


app.command(
    name="space",
    help=(
        "Alias for `spaces`. Export all pages in a Confluence space by URL to Markdown.\n\n"
        "See `cme spaces --help` for full documentation and all supported URL formats."
    ),
    epilog=("**Example:**\n\n- `cme space https://company.atlassian.net/wiki/spaces/MYSPACE`\n\n"),
)(spaces)


@app.command(
    help=(
        "Export **all spaces** of one or more Confluence organizations to Markdown.\n\n"
        "Iterates over every space in the organization and exports all pages in each. "
        "This is the broadest export scope — use `spaces` to target specific spaces, "
        "or `pages` / `pages-with-descendants` for finer-grained control.\n\n"
        "The base URL is the root of the Confluence instance, "
        "e.g. `https://company.atlassian.net`."
    ),
    epilog=(
        "**Examples:**\n\n"
        "- `cme orgs https://company.atlassian.net` — export everything\n\n"
        "- `cme orgs https://company1.atlassian.net https://company2.atlassian.net`"
        " — multiple orgs\n\n"
        "- `cme org URL` — singular alias, identical behaviour\n\n"
    ),
)
def orgs(
    base_urls: Annotated[
        list[str],
        typer.Argument(
            help=(
                "One or more Confluence base URLs (root of the instance). "
                "All spaces and pages within each organization will be exported. "
                "Example: https://company.atlassian.net"
            ),
            metavar="BASE_URL",
        ),
    ],
) -> None:
    from confluence_markdown_exporter.confluence import Organization
    from confluence_markdown_exporter.confluence import sync_removed_pages

    _init_logging()
    with measure("Export all spaces"):
        LockfileManager.init()

        for base_url in base_urls:
            org = Organization.from_url(base_url)
            org.export()
            sync_removed_pages(base_url)

    _print_summary()


app.command(
    name="org",
    help=(
        "Alias for `orgs`. "
        "Export all spaces of a Confluence organization to Markdown.\n\n"
        "See `cme orgs --help` for full documentation."
    ),
    epilog=("**Example:**\n\n- `cme org https://company.atlassian.net`\n\n"),
)(orgs)


@app.command(
    help="Show the installed version of confluence-markdown-exporter.",
)
def version() -> None:
    """Display the current version."""
    typer.echo(f"confluence-markdown-exporter {__version__}")


_ATLASSIAN_NET = "atlassian.net"
_REDACTED = "[redacted]"


def _redact_url(url: str) -> str:
    """Redact the instance URL.

    Atlassian Cloud URLs (``*.atlassian.net``) are kept as
    ``******.atlassian.net`` so the instance type is still visible.
    All other URLs are fully replaced with ``[redacted]``.
    """
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname or ""
    if host == _ATLASSIAN_NET or host.endswith(f".{_ATLASSIAN_NET}"):
        return f"https://******.{_ATLASSIAN_NET}"
    return _REDACTED


def _redact_config(data: dict) -> dict:
    """Return a deep copy of the config dict with sensitive values redacted.

    Redacted fields: ``api_token``, ``pat``, ``username``, ``cloud_id`` (when non-empty),
    ``export.output_path``, and instance URL keys in ``auth.confluence`` / ``auth.jira``.
    """
    import copy

    data = copy.deepcopy(data)
    for service in ("confluence", "jira"):
        auth_section: dict = data.get("auth", {}).get(service, {})
        redacted_section: dict = {}
        for url, details in auth_section.items():
            if isinstance(details, dict):
                for field in ("api_token", "pat", "username", "cloud_id"):
                    if details.get(field):
                        details[field] = _REDACTED
            redacted_section[_redact_url(url)] = details
        data.setdefault("auth", {})[service] = redacted_section
    if data.get("export", {}).get("output_path"):
        data["export"]["output_path"] = _REDACTED
    return data


@app.command(
    help=(
        "Print diagnostic information for filing a bug report.\n\n"
        "Outputs the app version, Python and OS details, and the current configuration "
        "with all secrets redacted (API tokens and PATs are masked; "
        "instance URL hostnames are partially hidden).\n\n"
        "Paste the full output into your GitHub issue when reporting a bug."
    ),
)
def bugreport() -> None:
    """Print version, system info, and redacted config for bug reports."""
    settings = get_settings()
    config_data = json.loads(settings.model_dump_json())
    redacted = _redact_config(config_data)

    lines: list[str] = [
        "## Bug Report Diagnostic Info",
        "",
        "### Version",
        f"confluence-markdown-exporter {__version__}",
        "",
        "### System",
        f"Python: {sys.version}",
        f"Platform: {platform.platform()}",
        f"Architecture: {platform.machine()}",
        "",
        "### Config",
        f"Config file: {_REDACTED}",
        "```yaml",
        yaml.dump(redacted, default_flow_style=False, allow_unicode=True).rstrip(),
        "```",
    ]
    typer.echo("\n".join(lines))


if __name__ == "__main__":
    app()
