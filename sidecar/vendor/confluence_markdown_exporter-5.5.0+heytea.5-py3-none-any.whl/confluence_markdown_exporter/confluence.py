"""Confluence API documentation.

https://developer.atlassian.com/cloud/confluence/rest/v1/intro
"""

import base64
import copy
import functools
import html
import json
import logging
import mimetypes
import os
import re
import time
import unicodedata
import urllib.parse
import zlib
from collections.abc import Set
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from os import PathLike
from pathlib import Path
from string import Template
from typing import Any
from typing import ClassVar
from typing import Literal
from typing import TypeAlias
from typing import cast
from urllib.parse import unquote
from urllib.parse import unquote_plus
from urllib.parse import urlparse

import requests
import yaml
from atlassian import Confluence as ConfluenceApiSdk
from atlassian.errors import ApiError
from atlassian.errors import ApiNotFoundError
from bs4 import BeautifulSoup
from bs4 import Tag
from markdownify import ATX
from markdownify import MarkdownConverter
from pydantic import BaseModel
from pydantic import Field
from requests import HTTPError
from requests import RequestException
from requests.exceptions import ChunkedEncodingError
from requests.exceptions import ConnectionError as RequestConnectionError
from requests.exceptions import Timeout
from rich.progress import BarColumn
from rich.progress import MofNCompleteColumn
from rich.progress import Progress
from rich.progress import SpinnerColumn
from rich.progress import TaskProgressColumn
from rich.progress import TextColumn
from rich.progress import TimeElapsedColumn
from rich.progress import TimeRemainingColumn
from tabulate import tabulate

from confluence_markdown_exporter.api_clients import JiraAuthenticationError
from confluence_markdown_exporter.api_clients import build_gateway_url
from confluence_markdown_exporter.api_clients import get_confluence_instance
from confluence_markdown_exporter.api_clients import get_jira_instance
from confluence_markdown_exporter.api_clients import get_thread_confluence
from confluence_markdown_exporter.api_clients import handle_jira_auth_failure
from confluence_markdown_exporter.api_clients import parse_confluence_path
from confluence_markdown_exporter.api_clients import parse_gateway_url
from confluence_markdown_exporter.utils.app_data_store import get_settings
from confluence_markdown_exporter.utils.app_data_store import normalize_instance_url
from confluence_markdown_exporter.utils.drawio_converter import load_and_parse_drawio
from confluence_markdown_exporter.utils.export import github_heading_slug
from confluence_markdown_exporter.utils.export import sanitize_filename
from confluence_markdown_exporter.utils.export import sanitize_key
from confluence_markdown_exporter.utils.export import save_file
from confluence_markdown_exporter.utils.lockfile import AttachmentEntry
from confluence_markdown_exporter.utils.lockfile import LockfileManager
from confluence_markdown_exporter.utils.page_registry import PageTitleRegistry
from confluence_markdown_exporter.utils.rich_console import ExportStats
from confluence_markdown_exporter.utils.rich_console import console
from confluence_markdown_exporter.utils.rich_console import get_stats
from confluence_markdown_exporter.utils.rich_console import reset_stats
from confluence_markdown_exporter.utils.table_converter import _MAX_TABLE_LINE_LEN
from confluence_markdown_exporter.utils.table_converter import TableConverter
from confluence_markdown_exporter.utils.table_converter import normalize_table_cell_text
from confluence_markdown_exporter.utils.table_converter import to_markdown_table

JsonResponse: TypeAlias = dict
StrPath: TypeAlias = str | PathLike[str]

logger = logging.getLogger(__name__)
_MAX_UNICODE_CODEPOINT = 0x10FFFF
_PAGE_SEARCH_MAX_ATTEMPTS = 3

# Rows requested per call when fetching all Page Properties Report entries.
_REPORT_FETCH_PAGE_SIZE = 50

# Upper bound for an inflated `plantumlcloud` payload. Deflate reaches ~1000:1, so an
# unbounded inflate of remote page content could exhaust memory.
_MAX_PLANTUML_SOURCE_BYTES = 4 * 1024 * 1024

_RE_RGB_BG = re.compile(r"background-color:\s*rgb\((\d+),\s*(\d+),\s*(\d+)\)")
_RE_RGB_COLOR = re.compile(r"(?<![a-z-])color:\s*rgb\((\d+),\s*(\d+),\s*(\d+)\)")
_RE_COLORID_CSS = re.compile(r"(?<![>\w])\[data-colorid=(\w+)\]\{color:(#[0-9a-fA-F]+)\}")
_RE_HEX_COLOR = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")

# Confluence default header backgrounds — applied automatically to <th> cells, and
# (in matrix-style tables) to row-label <td>s. Treated as "no user-chosen colour".
_DEFAULT_HEADER_BGS = frozenset({"#f4f5f7", "#f2f2f2"})

# Storage-format tag names, with and without the `ac:` prefix. Which form is present
# depends on the parser: `html.parser` keeps the prefix, the `xml` parser strips it.
_AC_MACRO_TAGS = ["ac:structured-macro", "structured-macro"]
_AC_PARAMETER_TAGS = ["ac:parameter", "parameter"]


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{r:02x}{g:02x}{b:02x}"


def _ac_attr(el: Tag, name: str) -> str:
    """Read a storage-format attribute, with or without the `ac:` prefix."""
    value = el.get(f"ac:{name}")
    if value is None:
        value = el.get(name, "")
    return str(value)


def _normalize_cql(cql: str) -> str:
    """Normalize a CQL string so it can be used as a lookup key.

    body.storage and body.export_view are produced by different renderers and may
    differ in incidental whitespace, so collapse it before comparing.
    """
    return " ".join(cql.split())


def _render_meta_bind_view_fields(props: dict[str, str], mode: str) -> str:
    """Render metadata as Meta Bind VIEW fields in a two-column markdown table."""
    table_data = [
        [f"**{k}**", f"`VIEW[{{{sanitize_key(k)}}}][text(renderMarkdown)]`"] for k in props
    ]
    headers = ["", ""]

    if mode == "compact":
        rendered = to_markdown_table(table_data, headers=headers, escape_cells=True)
    elif mode == "aligned":
        # Escape pipe characters before passing to tabulate
        escaped_data = [[normalize_table_cell_text(cell) for cell in row] for row in table_data]
        rendered = tabulate(escaped_data, headers=headers, tablefmt="pipe")
    else:
        # mixed mode (default)
        # Escape pipe characters before passing to tabulate
        escaped_data = [[normalize_table_cell_text(cell) for cell in row] for row in table_data]
        aligned = tabulate(escaped_data, headers=headers, tablefmt="pipe")
        max_line_len = max(len(line) for line in aligned.splitlines()) if aligned else 0
        if max_line_len > _MAX_TABLE_LINE_LEN:
            rendered = to_markdown_table(table_data, headers=headers, escape_cells=True)
        else:
            rendered = aligned
    return f"\n{rendered}\n"


def _extract_cell_highlight_hex(el: Tag) -> str | None:
    """Return Confluence cell background hex from data-highlight-colour, or None.

    Confluence Cloud sets `data-highlight-colour="#rrggbb"` (or `"transparent"`)
    on `<td>` / `<th>` when a cell background colour is applied.
    """
    val = el.get("data-highlight-colour")
    if not isinstance(val, str):
        return None
    val = val.strip().lower()
    if not val or val == "transparent" or val in _DEFAULT_HEADER_BGS:
        return None
    if _RE_HEX_COLOR.match(val):
        return val
    return None


# Background colours for Confluence status-badge lozenges (Atlassian design token pastels).
_LOZENGE_COLORS: dict[str, str] = {
    "aui-lozenge-complete": "#cce0ff",  # blue
    "aui-lozenge-success": "#baf3db",  # green
    "aui-lozenge-current": "#f8e6a0",  # yellow / orange
    "aui-lozenge-error": "#ffd5d2",  # red
    "aui-lozenge-progress": "#dfd8fd",  # purple / violet
}


def _require_dict(response: object, context: str) -> JsonResponse:
    """Validate that an API response is a dict, not an HTML redirect or error string.

    SAML SSO redirects and session-expiry responses are returned as raw HTML strings
    by the atlassian-python-api client instead of raising an exception.  Calling
    .get() on such a string produces a confusing AttributeError; this helper surfaces
    a clear message instead.
    """
    if isinstance(response, dict):
        return response
    preview = str(response)[:120].replace("\n", " ")
    if "SAMLRequest" in str(response) or "SAMLResponse" in str(response):
        msg = (
            f"Authentication failed for {context}: received a SAML SSO redirect instead of JSON. "
            "Check that your Confluence token/credentials are correct and not expired."
        )
    else:
        msg = f"Unexpected non-dict response for {context}: {preview!r}"
    raise ValueError(msg)


def _extract_base_url(url: str) -> str:
    """Extract the base URL from a Confluence or Jira URL.

    For Atlassian Cloud URLs (``*.atlassian.net``) returns ``{scheme}://{hostname}``.
    For Atlassian API gateway URLs of the form
    ``https://api.atlassian.com/ex/{service}/{cloudId}/...``
    returns ``https://api.atlassian.com/ex/{service}/{cloudId}`` so that
    the Cloud ID is preserved as part of the base URL used for auth lookup
    and SDK initialisation.
    For Server/Data Center instances with a context path (e.g.
    ``https://host/confluence/spaces/KEY``), the context path is preserved
    so the SDK client hits the correct REST endpoints.
    """
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme is None or parsed.hostname is None:
        msg = (
            "Invalid URL: a scheme (http:// or https://) and hostname are required. "
            "Expected format: 'https://<hostname>[:port]/...'."
        )
        raise ValueError(msg)

    if gateway := parse_gateway_url(url):
        return normalize_instance_url(build_gateway_url(*gateway))

    # For Server/DC instances the Confluence webapp may be deployed under a
    # context path (e.g. ``/confluence``).  Preserve everything before the
    # first path segment that belongs to Confluence's own routing.
    _confluence_route_segments = {
        "wiki",
        "display",
        "spaces",
        "rest",
        "pages",
        "plugins",
        "dosearchsite.action",
    }
    segments = [s for s in parsed.path.split("/") if s]
    context_parts: list[str] = []
    for segment in segments:
        if segment.lower() in _confluence_route_segments:
            break
        context_parts.append(segment)

    base = f"{parsed.scheme}://{parsed.hostname}"
    if parsed.port and parsed.port not in (80, 443):
        base = f"{parsed.scheme}://{parsed.hostname}:{parsed.port}"
    if context_parts:
        base = f"{base}/{'/'.join(context_parts)}"
    return normalize_instance_url(base)


def _join_confluence_link(data: JsonResponse, key: str) -> str:
    links = data.get("_links", {})
    if not isinstance(links, dict):
        return ""
    base = links.get("base")
    rel = links.get(key)
    if not isinstance(base, str) or not isinstance(rel, str) or not base or not rel:
        return ""
    return f"{base.rstrip('/')}/{rel.lstrip('/')}"


def _get_web_url(data: JsonResponse) -> str:
    return _join_confluence_link(data, "webui")


def _get_tiny_url(data: JsonResponse) -> str:
    return _join_confluence_link(data, "tinyui")


_JIRA_ROUTE_SEGMENTS = {
    "agile",
    "backlog",
    "board",
    "browse",
    "issues",
    "plugins",
    "projects",
    "rest",
    "secure",
    "servicedesk",
    "software",
}

_HTML_ELEMENTS = frozenset(
    {
        "a",
        "abbr",
        "acronym",
        "address",
        "area",
        "article",
        "aside",
        "audio",
        "b",
        "base",
        "bdi",
        "bdo",
        "blockquote",
        "body",
        "br",
        "button",
        "canvas",
        "caption",
        "cite",
        "code",
        "col",
        "colgroup",
        "data",
        "datalist",
        "dd",
        "del",
        "details",
        "dfn",
        "dialog",
        "div",
        "dl",
        "dt",
        "em",
        "embed",
        "fieldset",
        "figcaption",
        "figure",
        "font",
        "footer",
        "form",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "head",
        "header",
        "hgroup",
        "hr",
        "html",
        "i",
        "iframe",
        "img",
        "input",
        "ins",
        "kbd",
        "keygen",
        "label",
        "legend",
        "li",
        "link",
        "main",
        "map",
        "mark",
        "menu",
        "menuitem",
        "meta",
        "meter",
        "nav",
        "noscript",
        "object",
        "ol",
        "optgroup",
        "option",
        "output",
        "p",
        "picture",
        "pre",
        "progress",
        "q",
        "rp",
        "rt",
        "ruby",
        "s",
        "samp",
        "script",
        "section",
        "select",
        "small",
        "source",
        "span",
        "strong",
        "style",
        "sub",
        "summary",
        "sup",
        "table",
        "tbody",
        "td",
        "template",
        "textarea",
        "tfoot",
        "th",
        "thead",
        "time",
        "title",
        "tr",
        "track",
        "u",
        "ul",
        "var",
        "video",
        "wbr",
    }
)

_ANGLE_BRACKET_RE = re.compile(r"<([^<>\n]*)>")
_CODE_FENCE_RE = re.compile(r"^(`{3,}|~{3,})")
_INLINE_CODE_RE = re.compile(r"`[^`\n]*`")
_AUTOLINK_URI_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.\-]{1,31}:[^\s<>]*$")
_AUTOLINK_EMAIL_RE = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~\-]+@[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?"
    r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?)*$"
)


def _extract_jira_base_url(url: str) -> str | None:
    """Extract the Jira instance base URL from a Jira issue URL.

    Strips Jira-specific routing segments (e.g. ``browse``) so that the context
    path is preserved for Server/DC deployments (e.g. ``https://host/jira``),
    matching the key format used in ``auth.jira`` configuration.
    Returns ``None`` when *url* is not an absolute URL.
    """
    parsed = urllib.parse.urlparse(url)
    if not parsed.scheme or not parsed.hostname:
        return None

    if gateway := parse_gateway_url(url):
        return normalize_instance_url(build_gateway_url(*gateway))

    segments = [s for s in parsed.path.split("/") if s]
    context_parts: list[str] = []
    for segment in segments:
        if segment.lower() in _JIRA_ROUTE_SEGMENTS:
            break
        context_parts.append(segment)

    base = f"{parsed.scheme}://{parsed.hostname}"
    if parsed.port and parsed.port not in (80, 443):
        base = f"{parsed.scheme}://{parsed.hostname}:{parsed.port}"
    if context_parts:
        base = f"{base}/{'/'.join(context_parts)}"
    return normalize_instance_url(base)


settings = get_settings()


class JiraIssue(BaseModel):
    key: str
    summary: str
    description: str | None
    status: str

    @classmethod
    def from_json(cls, data: JsonResponse) -> "JiraIssue":
        fields = data.get("fields", {})
        return cls(
            key=data.get("key", ""),
            summary=fields.get("summary", ""),
            description=fields.get("description", ""),
            status=fields.get("status", {}).get("name", ""),
        )

    @classmethod
    def from_key(cls, issue_key: str, jira_url: str) -> "JiraIssue | None":
        """Fetch a Jira issue by key."""
        settings = get_settings()
        if not settings.export.enable_jira_enrichment:
            return None

        try:
            return cls._fetch_cached(issue_key, jira_url)
        except JiraAuthenticationError:
            handle_jira_auth_failure(jira_url)
            return None

    @classmethod
    @functools.lru_cache(maxsize=100)
    def _fetch_cached(cls, issue_key: str, jira_url: str) -> "JiraIssue":
        jira_instance = get_jira_instance(jira_url)
        issue_data = cast("JsonResponse", jira_instance.get_issue(issue_key))
        return cls.from_json(issue_data)


class User(BaseModel):
    account_id: str
    username: str
    display_name: str
    public_name: str
    email: str

    @classmethod
    def from_json(cls, data: JsonResponse) -> "User":
        return cls(
            account_id=data.get("accountId", ""),
            username=data.get("username", ""),
            display_name=data.get("displayName", ""),
            public_name=data.get("publicName", ""),
            email=data.get("email", ""),
        )

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_username(cls, username: str, base_url: str = "") -> "User":
        return cls.from_json(
            cast(
                "JsonResponse",
                get_thread_confluence(base_url).get_user_details_by_username(username),
            )
        )

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_userkey(cls, userkey: str, base_url: str = "") -> "User":
        return cls.from_json(
            cast(
                "JsonResponse",
                get_thread_confluence(base_url).get_user_details_by_userkey(userkey),
            )
        )

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_accountid(cls, accountid: str, base_url: str = "") -> "User":
        return cls.from_json(
            cast(
                "JsonResponse",
                get_thread_confluence(base_url).get_user_details_by_accountid(accountid),
            )
        )


class Version(BaseModel):
    number: int
    by: User
    when: str
    friendly_when: str

    @classmethod
    def from_json(cls, data: JsonResponse) -> "Version":
        return cls(
            number=data.get("number", 0),
            by=User.from_json(data.get("by", {})),
            when=data.get("when", ""),
            friendly_when=data.get("friendlyWhen", ""),
        )


class History(BaseModel):
    created: str
    created_by: User

    @classmethod
    def from_json(cls, data: JsonResponse) -> "History":
        return cls(
            created=data.get("createdDate", ""),
            created_by=User.from_json(data.get("createdBy", {})),
        )


@functools.lru_cache(maxsize=1000)
def _page_id_by_title(space_key: str, title: str, base_url: str) -> int | None:
    """Resolve a page id from its space key and title, or None if not found.

    Server/DC renders cross-space page links as ``/display/SPACE/Title`` without
    a page id. Cached because the same target is often linked from many pages.
    """
    try:
        page_data = get_thread_confluence(base_url).get_page_by_title(space=space_key, title=title)
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Could not resolve page '{title}' in space '{space_key}': {e}")
        return None
    if isinstance(page_data, dict) and str(page_data.get("id", "")).isdigit():
        return int(page_data["id"])
    return None


@functools.lru_cache(maxsize=10000)
def _has_child_pages(page_id: int, base_url: str) -> bool:
    """Return whether a page (or folder) has at least one descendant page."""
    try:
        response = get_thread_confluence(base_url).get(
            "rest/api/content/search",
            params={"cql": f"type=page AND ancestor={page_id}", "limit": 1},
        )
    except Exception:  # noqa: BLE001
        logger.warning(f"Could not check child pages of content ID {page_id}.")
        return False
    return bool(isinstance(response, dict) and response.get("results"))


def _page_path_template(page_id: int, base_url: str) -> str:
    """Pick export.page_path_if_parent for pages with children, else export.page_path."""
    parent_template = settings.export.page_path_if_parent
    if parent_template and _has_child_pages(page_id, base_url):
        return parent_template
    return settings.export.page_path


@functools.lru_cache(maxsize=10000)
def _link_target(page_id: int, base_url: str) -> "Descendant | None":
    """Fetch just enough of a linked page to build a link to it.

    Links only need the title, web URL and export path, so skip the page bodies
    and attachment listing that Page.from_id fetches. Returns None when the page
    cannot be read.
    """
    try:
        data = get_thread_confluence(base_url).get_page_by_id(page_id, expand="ancestors,version")
    except Exception:  # noqa: BLE001
        logger.debug("Could not fetch linked page id=%s", page_id, exc_info=True)
        return None
    if not isinstance(data, dict) or not data.get("id"):
        return None
    return Descendant.from_json(data, base_url)


class Organization(BaseModel):
    base_url: str
    spaces: list["Space"]

    @property
    def pages(self) -> list["Page | Descendant"]:
        return [page for space in self.spaces for page in space.pages]

    def export(self) -> None:
        """Export all pages across all spaces, showing per-space discovery progress."""
        all_pages: list[Page | Descendant] = []
        n = len(self.spaces)
        logger.info("Exporting %d space(s) from %s", n, self.base_url)
        with console.status("", spinner="dots") as status:
            for i, space in enumerate(self.spaces, 1):
                status.update(
                    f"[dim]Fetching pages for space [highlight]{space.name}[/highlight]"
                    f" ({i}/{n})…[/dim]"
                )
                all_pages.extend(space.pages)
        logger.info("Discovered %d page(s) across %d space(s)", len(all_pages), n)
        export_pages(all_pages)

    @classmethod
    def from_json(cls, data: JsonResponse, base_url: str) -> "Organization":
        return cls(
            base_url=base_url,
            spaces=[Space.from_json(space, base_url) for space in data.get("results", [])],
        )

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_url(cls, base_url: str) -> "Organization":
        logger.debug("Fetching space list from %s", base_url)
        with console.status(
            f"[dim]Fetching space list from [highlight]{base_url}[/highlight]…[/dim]"
        ):
            org = cls.from_json(
                cast(
                    "JsonResponse",
                    get_thread_confluence(base_url).get_all_spaces(
                        space_type="global", space_status="current", expand="homepage"
                    ),
                ),
                base_url,
            )
        logger.info("Found %d space(s) in %s", len(org.spaces), base_url)
        return org


class Space(BaseModel):
    base_url: str
    key: str
    name: str
    description: str
    homepage: int | None

    @property
    def pages(self) -> list["Page | Descendant"]:
        pages: list[Page | Descendant] = []
        if self.homepage is not None:
            homepage = Page.from_id(self.homepage, self.base_url)
            pages = [homepage, *homepage.descendants]

        if not settings.export.only_homepage_descendants:
            seen = {int(p.id) for p in pages}
            pages.extend(
                d
                for d in _search_pages(f'type=page AND space="{self.key}"', self.base_url)
                if int(d.id) not in seen
            )
            return pages

        if self.homepage is None:
            logger.warning(
                f"Space '{self.name}' (key: {self.key}) has no homepage. No pages will be "
                "exported. Set export.only_homepage_descendants=false to export all pages "
                "in the space."
            )
        else:
            self._warn_about_skipped_pages(len(pages))
        return pages

    def _warn_about_skipped_pages(self, found: int) -> None:
        """Warn when the space holds pages outside the homepage tree."""
        try:
            response = get_thread_confluence(self.base_url).get(
                "rest/api/search", params={"cql": f'type=page AND space="{self.key}"', "limit": 0}
            )
            total = int(response.get("totalSize", 0)) if isinstance(response, dict) else 0
        except Exception:  # noqa: BLE001
            return
        if total > found:
            logger.warning(
                f"Space '{self.name}' (key: {self.key}) has {total - found} page(s) outside "
                "the homepage tree that are not exported. Set "
                "export.only_homepage_descendants=false to include them."
            )

    def export(self) -> None:
        """Export all pages in this space to Markdown."""
        logger.debug("Fetching pages for space '%s' (%s)", self.name, self.key)
        with console.status(
            f"[dim]Fetching pages for space [highlight]{self.name}[/highlight]…[/dim]"
        ):
            pages = self.pages
        logger.info("Found %d page(s) in space '%s'", len(pages), self.name)
        export_pages(pages)

    @classmethod
    def from_json(cls, data: JsonResponse, base_url: str) -> "Space":
        return cls(
            base_url=base_url,
            key=data.get("key", ""),
            name=data.get("name", ""),
            description=data.get("description", {}).get("plain", {}).get("value", ""),
            homepage=data.get("homepage", {}).get("id"),
        )

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_key(cls, space_key: str, base_url: str) -> "Space":
        return cls.from_json(
            cast(
                "JsonResponse",
                get_thread_confluence(base_url).get_space(space_key, expand="homepage"),
            ),
            base_url,
        )

    @classmethod
    def from_url(cls, space_url: str) -> "Space":
        """Retrieve a Space object given a Confluence space URL.

        The Confluence instance is selected automatically by matching the URL's
        hostname against configured instances.  If no match is found, a new
        entry is registered in the auth config so the user can fill in
        credentials via the interactive config menu.

        Supports standard instance URLs (``https://company.atlassian.net/wiki/spaces/KEY``)
        and Atlassian API gateway URLs
        (``https://api.atlassian.com/ex/confluence/{cloudId}/wiki/spaces/KEY``).
        """
        base_url = _extract_base_url(space_url)

        # Ensure a client exists (creates/prompts if first time for this host)
        get_confluence_instance(base_url)

        parsed = urllib.parse.urlparse(space_url)
        base_path = urllib.parse.urlparse(base_url).path.rstrip("/")
        relative_path = parsed.path[len(base_path) :]
        if match := parse_confluence_path(relative_path):
            if match.space_key:
                logger.debug("Resolved space key '%s' from URL %s", match.space_key, space_url)
                return cls.from_key(match.space_key, base_url)

        msg = f"Could not parse space URL {space_url}."
        raise ValueError(msg)


class Folder(BaseModel):
    """A Confluence Cloud folder. Exporting it exports every page beneath it."""

    base_url: str
    id: int
    title: str

    @property
    def pages(self) -> list["Descendant"]:
        return _search_pages(f"type=page AND ancestor={self.id}", self.base_url)

    def export(self) -> None:
        with console.status(
            f"[dim]Fetching pages in folder [highlight]{self.title}[/highlight]…[/dim]"
        ):
            pages = self.pages
        logger.info("Found %d page(s) in folder '%s'", len(pages), self.title)
        export_pages(pages)

    @classmethod
    @functools.lru_cache(maxsize=100)
    def from_id(cls, folder_id: int, base_url: str) -> "Folder":
        data = _require_dict(
            get_thread_confluence(base_url).get(f"rest/api/content/{folder_id}"),
            f"folder id={folder_id}",
        )
        if data.get("type") != "folder":
            msg = f"Content {folder_id} is a {data.get('type')!r}, not a folder."
            raise ValueError(msg)
        return cls(base_url=base_url, id=int(data["id"]), title=data.get("title", ""))

    @classmethod
    def from_url(cls, folder_url: str) -> "Folder":
        """Retrieve a Folder given a URL like ``.../wiki/spaces/KEY/folder/123``."""
        base_url = _extract_base_url(folder_url)
        get_confluence_instance(base_url)

        if match := re.search(r"/folders?/(\d+)", urllib.parse.urlparse(folder_url).path):
            return cls.from_id(int(match.group(1)), base_url)

        msg = f"Could not parse folder URL {folder_url}."
        raise ValueError(msg)


class Label(BaseModel):
    id: str
    name: str
    prefix: str

    @classmethod
    def from_json(cls, data: JsonResponse) -> "Label":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            prefix=data.get("prefix", ""),
        )


class Document(BaseModel):
    base_url: str
    title: str
    space: Space
    ancestors: list["Ancestor"]
    version: Version

    @property
    def _template_vars(self) -> dict[str, str]:
        homepage_id = ""
        homepage_title = ""
        if self.space.homepage:
            homepage_id = str(self.space.homepage)
            homepage_title = sanitize_filename(
                Page.from_id(self.space.homepage, self.base_url).title
            )

        return {
            "space_key": sanitize_filename(self.space.key),
            "space_name": sanitize_filename(self.space.name),
            "homepage_id": homepage_id,
            "homepage_title": homepage_title,
            "ancestor_ids": "/".join(str(a.id) for a in self.ancestors),
            "ancestor_titles": "/".join(sanitize_filename(a.title) for a in self.ancestors),
        }


# A plausible file extension: a dot and 1-10 alphanumerics. Rejects suffixes
# like ".2 notes" that Path.suffix returns for titles such as "v1.2 notes".
_TITLE_EXTENSION_RE = re.compile(r"\.[A-Za-z0-9]{1,10}")


class Attachment(Document):
    id: str
    file_size: int
    media_type: str
    media_type_description: str
    file_id: str
    collection_name: str
    download_link: str
    comment: str
    # Populated by from_page_id()/from_json() from the owning page - Document itself has no
    # page context (only space/homepage/ancestors), unlike Page/Descendant which add page_id/
    # page_title on top. Kept optional (empty string default) for backward compatibility with
    # any other from_json() call site that does not know the owning page.
    page_id: str = ""
    page_title: str = ""

    @property
    def extension(self) -> str:
        # media_type is unique to draw.io diagram sources, so it alone is a
        # reliable, locale-independent discriminator. `comment` is not: Confluence
        # localizes it to the editing user's language (e.g. "diagramme draw.io" in
        # French vs. "draw.io diagram" in English), so matching it exactly caused
        # diagrams authored by non-English users to silently lose their extension.
        if self.media_type == "application/vnd.jgraph.mxfile":
            return ".drawio"
        if self.comment == "draw.io preview" and self.media_type == "image/png":
            return ".drawio.png"

        if self.media_type == "application/gliffy+json":
            return ".gliffy"

        guessed = mimetypes.guess_extension(self.media_type)
        if guessed and guessed != ".bin":
            return guessed

        # The attachment title is the original filename chosen at upload time.
        # Fall back to its extension for file types unknown to the stdlib (e.g.
        # .eddx mind maps sent as application/octet-stream), which would
        # otherwise be exported as .bin or without any extension.
        title_ext = Path(self.title).suffix
        if _TITLE_EXTENSION_RE.fullmatch(title_ext):
            return title_ext
        return guessed or ""

    @property
    def filename(self) -> str:
        return f"{self.file_id}{self.extension}"

    @property
    def _template_vars(self) -> dict[str, str]:
        ext = self.extension
        title = self.title
        title_without_ext = title[: -len(ext)] if ext and title.endswith(ext) else Path(title).stem
        return {
            **super()._template_vars,
            "page_id": self.page_id,
            "page_title": sanitize_filename(self.page_title) if self.page_title else "",
            "attachment_id": str(self.id),
            "attachment_title": sanitize_filename(title_without_ext),
            # file_id is a GUID and does not need sanitization. On
            # Confluence Data Center / Server the API does not populate
            # fileId, so fall back to the content id which is always
            # present and unique.
            "attachment_file_id": self.file_id or str(self.id),
            "attachment_extension": self.extension,
            "ancestors_without_last": "/".join(
                sanitize_filename(a.title) for a in self.ancestors[:-1]
            ),
        }

    @property
    def export_path(self) -> Path:
        template = settings.export.attachment_path
        parent_template = settings.export.attachment_path_if_parent
        owner_id = int(self.page_id) if self.page_id else None
        if owner_id is None and self.ancestors:
            owner_id = self.ancestors[-1].id
        if parent_template and owner_id and _has_child_pages(owner_id, self.base_url):
            template = parent_template
        filepath_template = Template(template.replace("{", "${"))
        return Path(filepath_template.safe_substitute(self._template_vars))

    @classmethod
    def from_json(
        cls, data: JsonResponse, base_url: str, *, page_id: str = "", page_title: str = ""
    ) -> "Attachment":
        extensions = data.get("extensions", {})
        container = data.get("container", {})
        space = Space.from_key(
            data.get("_expandable", {}).get("space", "").split("/")[-1], base_url
        )
        return cls(
            base_url=base_url,
            id=data.get("id", ""),
            title=data.get("title", ""),
            space=space,
            file_size=extensions.get("fileSize", 0),
            media_type=extensions.get("mediaType", ""),
            media_type_description=extensions.get("mediaTypeDescription", ""),
            file_id=extensions.get("fileId", ""),
            collection_name=extensions.get("collectionName", ""),
            download_link=data.get("_links", {}).get("download", ""),
            comment=extensions.get("comment", ""),
            page_id=page_id,
            page_title=page_title,
            ancestors=_without_homepage(
                [
                    *[
                        Ancestor.from_json(ancestor, base_url)
                        for ancestor in container.get("ancestors", [])
                    ],
                    Ancestor.from_json(container, base_url),
                ],
                space,
            ),
            version=Version.from_json(data.get("version", {})),
        )

    @classmethod
    def from_page_id(cls, page_id: int, base_url: str, page_title: str = "") -> list["Attachment"]:
        attachments = []
        start = 0
        paging_limit = 50
        size = paging_limit  # Initialize to limit to enter the loop

        while size >= paging_limit:
            response = cast(
                "JsonResponse",
                get_thread_confluence(base_url).get_attachments_from_content(
                    page_id,
                    start=start,
                    limit=paging_limit,
                    expand="container.ancestors,version",
                ),
            )

            attachments.extend(
                [
                    cls.from_json(att, base_url, page_id=str(page_id), page_title=page_title)
                    for att in response.get("results", [])
                ]
            )

            size = response.get("size", 0)
            start += size

        logger.debug("Found %d attachment(s) for page id=%s", len(attachments), page_id)
        return attachments

    def export(self) -> None:
        stats = get_stats()
        filepath = settings.export.output_path / self.export_path
        if filepath.exists():
            logger.debug("Skipping attachment '%s' — already exists at %s", self.title, filepath)
            return

        logger.debug("Downloading attachment '%s' to %s", self.title, filepath)
        client = get_thread_confluence(self.base_url)
        try:
            try:
                response = self._download(client, client.url + self.download_link)
            except HTTPError:
                # Scoped API tokens are rejected on /download/attachments/... links
                # ("scope does not match"), but may use the REST download endpoint.
                if not (rest_link := self._rest_download_link()):
                    raise
                logger.debug("Retrying download of '%s' via %s", self.title, rest_link)
                response = self._download(client, client.url + rest_link)
        except HTTPError:
            logger.warning("There is no attachment with title '%s'. Skipping export.", self.title)
            stats.inc_attachments_failed()
            return
        except RequestException as e:
            logger.warning("Failed to download attachment '%s': %s. Skipping.", self.title, e)
            stats.inc_attachments_failed()
            return

        save_file(filepath, response.content)
        logger.debug("Saved attachment '%s' (%d bytes)", self.title, len(response.content))
        stats.inc_attachments_exported()

    @staticmethod
    def _download(client: ConfluenceApiSdk, url: str) -> requests.Response:
        response = client.request(method="GET", path=url, absolute=True, advanced_mode=True)
        response.raise_for_status()
        return response

    def _rest_download_link(self) -> str | None:
        """Return the REST API download path, unless it is the link already tried."""
        page_id = self.page_id or (str(self.ancestors[-1].id) if self.ancestors else "")
        if not page_id or self.download_link.startswith("/rest/"):
            return None
        return f"/rest/api/content/{page_id}/child/attachment/{self.id}/download"


class Ancestor(Document):
    id: int

    @classmethod
    def from_json(cls, data: JsonResponse, base_url: str) -> "Ancestor":
        return cls(
            base_url=base_url,
            id=data.get("id", 0),
            title=data.get("title", ""),
            space=Space.from_key(
                data.get("_expandable", {}).get("space", "").split("/")[-1], base_url
            ),
            ancestors=[],  # Ancestors of ancestor is not needed for now.
            version=Version.from_json({}),  # Version of ancestor is not needed for now.
        )


def _search_pages(cql: str, base_url: str) -> list["Descendant"]:
    """Return every page matching *cql*, following pagination."""
    url = "rest/api/content/search"
    params = {
        "cql": cql,
        "expand": "ancestors,version",
        "limit": 250,
    }
    results = []
    client = get_thread_confluence(base_url)

    def get(path: str, params: dict | None = None) -> JsonResponse:
        attempt = 0
        while True:
            attempt += 1
            try:
                response = (
                    client.get(path, params=params) if params is not None else client.get(path)
                )
                return cast("dict", response)
            except (ChunkedEncodingError, RequestConnectionError, Timeout):
                if attempt == _PAGE_SEARCH_MAX_ATTEMPTS:
                    raise
                time.sleep(attempt)

    response = get(url, params=params)
    results.extend(response.get("results", []))
    next_path = response.get("_links", {}).get("next")

    while next_path:
        response = get(next_path)
        results.extend(response.get("results", []))
        next_path = response.get("_links", {}).get("next")
    return [Descendant.from_json(result, base_url) for result in results]


def _without_homepage(ancestors: list["Ancestor"], space: Space) -> list["Ancestor"]:
    """Drop the space homepage from the front of an ancestor chain.

    Pages outside the homepage tree (a second root page in the space) keep
    their whole chain, so they still nest under their own root in the export.
    """
    if ancestors and (space.homepage is None or ancestors[0].id == space.homepage):
        return ancestors[1:]
    return ancestors


class Descendant(Document):
    id: int
    web_url: str = ""

    @property
    def _template_vars(self) -> dict[str, str]:
        return {
            **super()._template_vars,
            "page_id": str(self.id),
            "page_title": sanitize_filename(self.title),
        }

    @property
    def export_path(self) -> Path:
        template = _page_path_template(self.id, self.base_url)
        filepath_template = Template(template.replace("{", "${"))
        return Path(filepath_template.safe_substitute(self._template_vars))

    @classmethod
    def from_json(cls, data: JsonResponse, base_url: str) -> "Descendant":
        space = Space.from_key(
            data.get("_expandable", {}).get("space", "").split("/")[-1], base_url
        )
        return cls(
            base_url=base_url,
            id=data.get("id", 0),
            title=data.get("title", ""),
            web_url=_get_web_url(data),
            space=space,
            ancestors=_without_homepage(
                [Ancestor.from_json(ancestor, base_url) for ancestor in data.get("ancestors", [])],
                space,
            ),
            version=Version.from_json(data.get("version", {})),
        )


def _parse_image_captions(storage_xml: str) -> dict[str, str]:
    """Return {filename: caption} parsed from Confluence storage-format XML."""
    captions: dict[str, str] = {}
    if not storage_xml:
        return captions
    for block in re.findall(r"<ac:image[^>]*>.*?</ac:image>", storage_xml, re.DOTALL):
        filename_m = re.search(r'ri:filename="([^"]+)"', block)
        if not filename_m:
            continue
        caption_m = re.search(r"<ac:caption[^>]*>(.*?)</ac:caption>", block, re.DOTALL)
        if not caption_m:
            continue
        caption_content = caption_m.group(1)
        # CDATA in ac:plain-text-body (older format)
        cdata_m = re.search(
            r"<ac:plain-text-body>\s*<!\[CDATA\[(.*?)\]\]>\s*</ac:plain-text-body>",
            caption_content,
            re.DOTALL,
        )
        if cdata_m:
            caption = cdata_m.group(1).strip()
        else:
            # HTML elements in caption (e.g. <p>text</p>) — strip tags
            caption = BeautifulSoup(caption_content, "html.parser").get_text().strip()
        if caption:
            captions[filename_m.group(1)] = caption
    return captions


class Page(Document):
    id: int
    type: str = ""
    web_url: str = ""
    tiny_url: str = ""
    body: str
    body_export: str
    editor2: str
    body_storage: str = ""
    labels: list["Label"]
    attachments: list["Attachment"]
    history: History = Field(
        default_factory=lambda: History(created="", created_by=User.from_json({}))
    )

    @property
    def descendants(self) -> list["Descendant"]:
        return _search_pages(f"type=page AND ancestor={self.id}", self.base_url)

    @property
    def _template_vars(self) -> dict[str, str]:
        return {
            **super()._template_vars,
            "page_id": str(self.id),
            "page_title": sanitize_filename(self.title),
        }

    @property
    def export_path(self) -> Path:
        template = _page_path_template(self.id, self.base_url)
        filepath_template = Template(template.replace("{", "${"))
        return Path(filepath_template.safe_substitute(self._template_vars))

    @property
    def html(self) -> str:
        if settings.export.include_document_title:
            return f"<h1>{self.title}</h1>{self.body}"
        return self.body

    @property
    def markdown(self) -> str:
        return self.Converter(self).markdown

    def export(self) -> dict[str, AttachmentEntry]:
        if self.title == "Page not accessible":
            logger.warning("Skipping export for inaccessible page id=%s", self.id)
            return {}

        logger.debug("Exporting page id=%s '%s'", self.id, self.title)
        if settings.export.log_level == "DEBUG":
            self.export_body()
        # Export attachments first so the files can be utilized during markdown conversion
        logger.debug("Exporting attachments for page id=%s", self.id)
        attachment_entries = self.export_attachments()
        logger.debug("Converting to Markdown for page id=%s", self.id)
        self.export_markdown()
        if settings.export.comments_export != "none":
            logger.debug("Exporting comments for page id=%s", self.id)
            self.export_comments_sidecar()
        logger.info(
            "Exported '%s' -> %s", self.title, settings.export.output_path / self.export_path
        )
        return attachment_entries

    def export_with_descendants(self) -> None:
        with console.status(
            f"[dim]Fetching descendants of [highlight]{self.title}[/highlight]…[/dim]"
        ):
            pages = [self, *self.descendants]
        export_pages(pages)

    def export_body(self) -> None:
        soup = BeautifulSoup(self.html, "html.parser")
        save_file(
            settings.export.output_path
            / self.export_path.parent
            / f"{self.export_path.stem}_body_view.html",
            str(soup.prettify()),
        )
        soup = BeautifulSoup(self.body_export, "html.parser")
        save_file(
            settings.export.output_path
            / self.export_path.parent
            / f"{self.export_path.stem}_body_export_view.html",
            str(soup.prettify()),
        )
        save_file(
            settings.export.output_path
            / self.export_path.parent
            / f"{self.export_path.stem}_body_editor2.xml",
            str(self.editor2),
        )

    def export_markdown(self) -> None:
        conv = self.Converter(self)
        save_file(
            settings.export.output_path / self.export_path,
            conv.markdown,
        )
        self._marked_texts: dict[str, str] = conv._marked_texts

    _COMMENT_TITLE_MAX_LEN = 60

    @classmethod
    def _truncate_excerpt(cls, text: str, max_len: int = _COMMENT_TITLE_MAX_LEN) -> str:
        """Strip Markdown links/formatting and truncate text at word boundary."""
        # Strip Markdown images ![alt](url) -> alt
        clean = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", text)
        # Strip Markdown links [text](url) -> text
        clean = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", clean)
        # Strip Wiki links [[url|text]] -> text, [[text]] -> text
        clean = re.sub(r"\[\[(?:[^|\]]*\|)?([^\]]+)\]\]", r"\1", clean)
        # Collapse whitespace
        clean = re.sub(r"\s+", " ", clean).strip()

        if len(clean) <= max_len:
            return clean

        truncated = clean[:max_len]
        if " " in truncated:
            truncated = truncated.rsplit(" ", 1)[0]
        return truncated.rstrip(".,:;!? ") + "…"

    def _fetch_inline_comments(self) -> list[dict]:
        client = get_thread_confluence(self.base_url)
        results: list[dict] = []
        try:
            resp = cast(
                "dict",
                client.get_page_comments(
                    self.id,
                    location="inline",
                    expand="extensions.inlineProperties,extensions.resolution,body.view,history.createdBy",
                    limit=50,
                ),
            )
            for comment in resp.get("results", []):
                status = comment.get("extensions", {}).get("resolution", {}).get("status", "open")
                if status == "open":
                    results.append(comment)
            next_path = resp.get("_links", {}).get("next")
            while next_path:
                resp = cast("dict", client.get(next_path))
                for comment in resp.get("results", []):
                    status = (
                        comment.get("extensions", {}).get("resolution", {}).get("status", "open")
                    )
                    if status == "open":
                        results.append(comment)
                next_path = resp.get("_links", {}).get("next")
        except Exception:  # noqa: BLE001
            logger.warning("Failed to fetch inline comments for page id=%s", self.id)
        return results

    def _fetch_page_comments(self) -> list[dict]:
        client = get_thread_confluence(self.base_url)
        results: list[dict] = []
        try:
            resp = cast(
                "dict",
                client.get_page_comments(
                    self.id,
                    location="footer",
                    expand="extensions.resolution,body.view,history.createdBy",
                    limit=50,
                ),
            )
            for comment in resp.get("results", []):
                status = comment.get("extensions", {}).get("resolution", {}).get("status", "open")
                if status == "open":
                    results.append(comment)
            next_path = resp.get("_links", {}).get("next")
            while next_path:
                resp = cast("dict", client.get(next_path))
                for comment in resp.get("results", []):
                    status = (
                        comment.get("extensions", {}).get("resolution", {}).get("status", "open")
                    )
                    if status == "open":
                        results.append(comment)
                next_path = resp.get("_links", {}).get("next")
        except Exception:  # noqa: BLE001
            logger.warning("Failed to fetch page comments for page id=%s", self.id)
        return results

    def _fetch_comment_replies(self, comment_id: str) -> list[dict]:
        client = get_thread_confluence(self.base_url)
        try:
            resp = cast(
                "dict",
                client.get(
                    f"rest/api/content/{comment_id}/child/comment",
                    params={"expand": "body.view,history.createdBy", "limit": 50},
                ),
            )
            return resp.get("results", [])
        except Exception:  # noqa: BLE001
            return []

    def export_comments_sidecar(self) -> None:
        mode = settings.export.comments_export
        inline = self._fetch_inline_comments() if mode in ("inline", "all") else []
        page = self._fetch_page_comments() if mode in ("footer", "all") else []
        if not inline and not page:
            return

        source_url = f"{self.base_url}/wiki/spaces/{self.space.key}/pages/{self.id}"

        lines: list[str] = [
            "---",
            f"confluence_page_id: '{self.id}'",
            f'confluence_page_title: "{self.title}"',
            f'confluence_webui_url: "{source_url}"',
            "---",
            "",
        ]

        if inline:
            lines.append("## Inline comments")
            lines.append("")
            self._render_inline_comments(lines, inline)

        if page:
            lines.append("## Page comments")
            lines.append("")
            self._render_page_comments(lines, page)

        save_file(
            settings.export.output_path
            / self.export_path.parent
            / f"{self.export_path.stem}.comments.md",
            "\n".join(lines),
        )

    def _render_inline_comments(self, lines: list[str], comments: list[dict]) -> None:
        for comment in comments:
            ref = comment.get("extensions", {}).get("inlineProperties", {}).get("markerRef", "")
            marked_md = self._marked_texts.get(ref, "")

            if settings.export.comment_headings:
                short_title = self._truncate_excerpt(marked_md)
                if not short_title:
                    short_title = f"Comment {ref[:8]}"
                lines.append(f"### {short_title}")
                lines.append("")

            if marked_md:
                lines.extend(
                    f"> {line}" if line.strip() else ">" for line in marked_md.splitlines()
                )
                lines.append("")

            author = comment.get("history", {}).get("createdBy", {}).get("displayName", "Unknown")
            created = comment.get("history", {}).get("createdDate", "")[:10]
            body_md = (
                MarkdownConverter()
                .convert(comment.get("body", {}).get("view", {}).get("value", ""))
                .strip()
            )

            lines.append(f"**{author}** · {created}")
            lines.append("")
            if body_md:
                lines.append(body_md)
                lines.append("")

            for reply in self._fetch_comment_replies(comment["id"]):
                r_author = (
                    reply.get("history", {}).get("createdBy", {}).get("displayName", "Unknown")
                )
                r_created = reply.get("history", {}).get("createdDate", "")[:10]
                r_body_md = (
                    MarkdownConverter()
                    .convert(reply.get("body", {}).get("view", {}).get("value", ""))
                    .strip()
                )
                lines.append(f"**{r_author}** · {r_created}")
                lines.append("")
                if r_body_md:
                    lines.append(r_body_md)
                    lines.append("")

    def _render_page_comments(self, lines: list[str], comments: list[dict]) -> None:
        for comment in comments:
            body_md = (
                MarkdownConverter()
                .convert(comment.get("body", {}).get("view", {}).get("value", ""))
                .strip()
            )

            if settings.export.comment_headings:
                short_title = self._truncate_excerpt(body_md)
                if not short_title:
                    short_title = f"Comment {str(comment.get('id', ''))[:8]}"
                lines.append(f"### {short_title}")
                lines.append("")

            author = comment.get("history", {}).get("createdBy", {}).get("displayName", "Unknown")
            created = comment.get("history", {}).get("createdDate", "")[:10]
            lines.append(f"**{author}** · {created}")
            lines.append("")
            if body_md:
                lines.append(body_md)
                lines.append("")

            for reply in self._fetch_comment_replies(comment["id"]):
                r_author = (
                    reply.get("history", {}).get("createdBy", {}).get("displayName", "Unknown")
                )
                r_created = reply.get("history", {}).get("createdDate", "")[:10]
                r_body_md = (
                    MarkdownConverter()
                    .convert(reply.get("body", {}).get("view", {}).get("value", ""))
                    .strip()
                )
                lines.append(f"**{r_author}** · {r_created}")
                lines.append("")
                if r_body_md:
                    lines.append(r_body_md)
                    lines.append("")

    @staticmethod
    def _extract_macro_diagrams(macro_type: str, soup: BeautifulSoup) -> set[str]:
        """Extract diagram attachment names from storage by macro type.

        Args:
            macro_type: Type of macro (e.g., 'gliffy', 'drawio')
            soup: Parsed BeautifulSoup storage XML

        Returns:
            Set of attachment names (includes both diagram name and .png preview)
        """
        names: set[str] = set()
        for macro in soup.find_all("structured-macro"):
            if not isinstance(macro, Tag) or macro.get("name") != macro_type:
                continue
            param = macro.find("parameter", {"name": "diagramName"})
            if isinstance(param, Tag):
                diag_name = param.get_text(strip=True)
                if diag_name:
                    names.add(diag_name)
                    names.add(f"{diag_name}.png")
        return names

    def _clientside_macro_attachment_names(self) -> set[str]:
        """Extract attachment names referenced in clientside-rendered macros.

        On Confluence Server/DC, some macros (gliffy, drawio) render clientside in
        body.view but their metadata is available in body.storage.

        Returns:
            Set of attachment titles that should be exported (e.g., {"diagram1", "diagram1.png"})
        """
        if not self.body_storage:
            return set()

        try:
            wrapped = f"<root>{self.body_storage}</root>"
            soup = BeautifulSoup(wrapped, "xml")
            names = Page._extract_macro_diagrams("gliffy", soup)
            names.update(Page._extract_macro_diagrams("drawio", soup))
            return names  # noqa: TRY300
        except Exception as e:  # noqa: BLE001
            logger.debug(f"Error parsing clientside macros from storage for page {self.id}: {e}")
            return set()

    def _attachments_for_export(self) -> list["Attachment"]:
        """Return the subset of attachments that should be exported for this page."""
        if settings.export.attachments_export == "all":
            return list(self.attachments)

        bodies = self.body + self.body_export
        clientside_names = self._clientside_macro_attachment_names()

        return [
            a
            for a in self.attachments
            if (
                a.file_id in bodies
                or a.id in bodies
                or a.title in bodies
                or a.title.replace(" ", "%20") in bodies
                or a.title in clientside_names
                or a.title.replace(" ", "%20") in clientside_names
            )
        ]

    def export_attachments(self) -> dict[str, AttachmentEntry]:
        if settings.export.attachments_export == "disabled":
            logger.debug("Attachment download disabled for page id=%s", self.id)
            return {}
        old_entries = LockfileManager.get_page_attachment_entries(str(self.id))
        new_entries: dict[str, AttachmentEntry] = {}
        output_path = settings.export.output_path
        stats = get_stats()

        for attachment in self._attachments_for_export():
            att_id = attachment.id
            att_version = attachment.version.number if attachment.version else 0

            # Skip download if the same attachment version is tracked and the file still exists
            if att_id in old_entries:
                old = old_entries[att_id]
                if old.version == att_version and (output_path / old.path).exists():
                    new_entries[att_id] = old
                    logger.debug(
                        "Skipping unchanged attachment '%s' (v%d)", attachment.title, att_version
                    )
                    stats.inc_attachments_skipped()
                    continue

            attachment.export()
            if att_version:
                new_entries[att_id] = AttachmentEntry(
                    version=att_version, path=str(attachment.export_path)
                )

        # Clean up orphaned attachment files when an attachment was re-versioned
        for att_id, old_entry in old_entries.items():
            if att_id in new_entries and old_entry.path != new_entries[att_id].path:
                old_file = output_path / old_entry.path
                old_file.unlink(missing_ok=True)
                logger.info("Deleted old attachment file: %s", old_entry.path)
                stats.inc_attachments_removed()

        return new_entries

    def get_attachment_by_id(self, attachment_id: str) -> Attachment | None:
        """Get the Attachment object by its ID.

        Confluence Server sometimes stores attachments without a file_id.
        Fall back to the plain attachment.id and return None if nothing matches.
        """
        for a in self.attachments:
            if attachment_id in a.id:
                return a
            if a.file_id and attachment_id in a.file_id:
                return a
        return None

    def get_attachment_by_file_id(self, file_id: str) -> Attachment | None:
        for a in self.attachments:
            if a.file_id and file_id in a.file_id:
                return a
        return None

    def get_attachments_by_title(self, title: str) -> list[Attachment]:
        return [attachment for attachment in self.attachments if attachment.title == title]

    @classmethod
    def from_json(cls, data: JsonResponse, base_url: str) -> "Page":
        space = Space.from_key(
            data.get("_expandable", {}).get("space", "").split("/")[-1], base_url
        )
        return cls(
            base_url=base_url,
            id=data.get("id", 0),
            type=data.get("type", ""),
            web_url=_get_web_url(data),
            tiny_url=_get_tiny_url(data),
            title=data.get("title", ""),
            space=space,
            body=data.get("body", {}).get("view", {}).get("value", ""),
            body_export=data.get("body", {}).get("export_view", {}).get("value", ""),
            editor2=data.get("body", {}).get("editor2", {}).get("value", ""),
            body_storage=data.get("body", {}).get("storage", {}).get("value", ""),
            labels=[
                Label.from_json(label)
                for label in data.get("metadata", {}).get("labels", {}).get("results", [])
            ],
            attachments=Attachment.from_page_id(
                data.get("id", 0), base_url, page_title=data.get("title", "")
            ),
            ancestors=_without_homepage(
                [Ancestor.from_json(ancestor, base_url) for ancestor in data.get("ancestors", [])],
                space,
            ),
            version=Version.from_json(data.get("version", {})),
            history=History.from_json(data.get("history", {})),
        )

    @classmethod
    @functools.lru_cache(maxsize=1000)
    def from_id(cls, page_id: int, base_url: str) -> "Page":
        _empty_space = Space(base_url=base_url, key="", name="", description="", homepage=0)
        if page_id is None:
            logger.warning("Page ID is None, returning empty page")
            return cls(
                base_url=base_url,
                id=0,
                title="Page not accessible",
                space=_empty_space,
                body="",
                body_export="",
                editor2="",
                labels=[],
                attachments=[],
                ancestors=[],
            )
        logger.debug("Fetching page id=%s from %s", page_id, base_url)
        expand = (
            "body.view,body.export_view,body.editor2,body.storage,metadata.labels,"
            "metadata.properties,ancestors,version,history,history.createdBy"
        )
        try:
            return cls.from_json(
                _require_dict(
                    get_thread_confluence(base_url).get_page_by_id(
                        page_id,
                        expand=expand,
                    ),
                    f"page id={page_id} at {base_url}",
                ),
                base_url,
            )
        except (ApiError, HTTPError):
            logger.warning("Could not access page id=%s — treating as inaccessible", page_id)
            return cls(
                base_url=base_url,
                id=page_id,
                title="Page not accessible",
                space=_empty_space,
                body="",
                body_export="",
                editor2="",
                labels=[],
                attachments=[],
                ancestors=[],
                version=Version.from_json({}),
            )

    @classmethod
    def from_url(cls, page_url: str) -> "Page":
        """Retrieve a Page object given a Confluence page URL.

        The Confluence instance is selected automatically by matching the URL's
        hostname against configured instances.  If no match is found, a new
        entry is registered in the auth config so the user can fill in
        credentials via the interactive config menu.

        Supports standard instance URLs and Atlassian API gateway URLs of the form
        ``https://api.atlassian.com/ex/confluence/{cloudId}/wiki/spaces/KEY/pages/123``.
        """
        base_url = _extract_base_url(page_url)

        # Ensure a client exists (creates/prompts if first time for this host)
        get_confluence_instance(base_url)

        parsed = urllib.parse.urlparse(page_url)
        query_params = urllib.parse.parse_qs(parsed.query)
        page_id_param = next(
            (
                values[0]
                for key, values in query_params.items()
                if key.lower() == "pageid" and values and values[0]
            ),
            None,
        )
        if page_id_param and page_id_param.isdigit():
            page_id = int(page_id_param)
            logger.debug(
                "Resolved page id=%s from Confluence query string in URL %s", page_id, page_url
            )
            return Page.from_id(page_id, base_url)

        base_path = urllib.parse.urlparse(base_url).path.rstrip("/")
        relative_path = parsed.path[len(base_path) :]
        if match := parse_confluence_path(relative_path):
            if match.page_id:
                logger.debug("Resolved page id=%s from Confluence URL %s", match.page_id, page_url)
                return Page.from_id(match.page_id, base_url)

            if match.space_key and match.page_title:
                logger.debug(
                    "Resolving page '%s' in space '%s' from Confluence URL %s",
                    match.page_title,
                    match.space_key,
                    page_url,
                )
                page_data = _require_dict(
                    get_thread_confluence(base_url).get_page_by_title(
                        space=match.space_key, title=match.page_title, expand="version"
                    ),
                    f"page title={match.page_title!r} space={match.space_key!r} at {base_url}",
                )
                return Page.from_id(page_data["id"], base_url)

        msg = f"Could not parse page URL {page_url}."
        raise ValueError(msg)

    class Converter(TableConverter, MarkdownConverter):
        """Create a custom MarkdownConverter for Confluence HTML to Markdown conversion."""

        class Options(MarkdownConverter.DefaultOptions):  # type: ignore[assignment]
            bullets = "-"
            heading_style = ATX
            macros_to_ignore: Set[str] = frozenset(["qc-read-and-understood-signature-box"])
            front_matter_indent = 2

        def __init__(self, page: "Page", **options) -> None:  # noqa: ANN003
            super().__init__(**options)
            self.page = page
            self.page_properties = {}
            self._marked_texts: dict[str, str] = {}
            self._colorid_map_cache: dict[str, str] | None = None
            self._image_captions_cache: dict[str, str] | None = None
            self._panel_icon_map_cache: dict[str, str] | None = None
            self._plantuml_index: int = 0
            self._plantumlcloud_index: int = 0
            self._storage_macros_cache: dict[str, list[Tag]] = {}
            self._storage_soup_cache: BeautifulSoup | None = None
            self._pagetree_descendants_cache: dict[tuple[int, int | None], list[Descendant]] = {}

        @property
        def _colorid_map(self) -> dict[str, str]:
            if self._colorid_map_cache is None:
                cache: dict[str, str] = {}
                soup = BeautifulSoup(self.page.html, "html.parser")
                for style_tag in soup.find_all("style"):
                    css = style_tag.get_text()
                    for m in _RE_COLORID_CSS.finditer(css):
                        color_id = m.group(1)
                        if color_id not in cache:
                            cache[color_id] = m.group(2)
                self._colorid_map_cache = cache
            return self._colorid_map_cache

        def _storage_macros_by_name(self, name: str) -> list[Tag]:
            """Cache and return all structured-macros with the given name from body.storage."""
            if name not in self._storage_macros_cache:
                macros: list[Tag] = []
                if self.page.body_storage:
                    wrapped = f"<root>{self.page.body_storage}</root>"
                    soup = BeautifulSoup(wrapped, "xml")
                    macros.extend(
                        macro
                        for macro in soup.find_all("structured-macro")
                        if isinstance(macro, Tag) and macro.get("name") == name
                    )
                self._storage_macros_cache[name] = macros
            return self._storage_macros_cache[name]

        @property
        def _image_captions(self) -> dict[str, str]:
            if self._image_captions_cache is None:
                self._image_captions_cache = _parse_image_captions(self.page.body_storage)
            return self._image_captions_cache

        @property
        def _panel_icon_map(self) -> dict[str, str]:
            """Map panel macro-id to its custom icon emoji from editor2 XML."""
            if self._panel_icon_map_cache is None:
                cache: dict[str, str] = {}
                if self.page.editor2:
                    wrapped = f"<root>{self.page.editor2}</root>"
                    soup = BeautifulSoup(wrapped, "xml")
                    panel_names = {"panel", "info", "note", "tip", "warning"}
                    for macro in soup.find_all("structured-macro"):
                        if not isinstance(macro, Tag):
                            continue
                        if macro.get("name") not in panel_names:
                            continue
                        macro_id = macro.get("macro-id")
                        if not macro_id:
                            continue
                        emoji = self._extract_panel_emoji(macro)
                        if emoji:
                            cache[str(macro_id)] = emoji
                self._panel_icon_map_cache = cache
            return self._panel_icon_map_cache

        @staticmethod
        def _macro_params(macro: Tag) -> dict[str, str]:
            """Map a structured-macro's direct `parameter` children to their values.

            Only direct children: a macro body may hold nested macros with parameters of
            their own. On a repeated name the last occurrence wins.
            """
            return {
                str(p.get("name")): p.get_text(strip=True)
                for p in macro.find_all("parameter", recursive=False)
                if isinstance(p, Tag) and p.get("name")
            }

        @classmethod
        def _extract_panel_emoji(cls, macro: Tag) -> str | None:
            params = cls._macro_params(macro)
            if text := params.get("panelIconText"):
                return text
            if icon_id := params.get("panelIconId"):
                try:
                    cps = [int(cp, 16) for cp in icon_id.split("-")]
                    if all(0 <= cp <= _MAX_UNICODE_CODEPOINT for cp in cps):
                        return "".join(chr(cp) for cp in cps)
                except (OverflowError, ValueError):
                    pass
            return None

        @property
        def markdown(self) -> str:
            html = self._strip_excerpt_include_panel_titles(self.page.html)
            html = self._inline_app_macro_bodies(html)
            md_body = self.convert(html)
            md_body = self._escape_template_placeholders(md_body)
            markdown = f"{self.front_matter}\n"
            if settings.export.page_breadcrumbs:
                markdown += f"{self.breadcrumbs}\n"
            markdown += f"{md_body}\n"
            return markdown

        @property
        def front_matter(self) -> str:
            indent = self.options["front_matter_indent"]
            self.set_page_properties(tags=self.labels)
            self._add_confluence_url_properties()
            self._add_page_metadata_properties()

            if not self.page_properties:
                return ""

            yml = yaml.dump(self.page_properties, indent=indent, allow_unicode=True).strip()
            # Indent the root level list items
            yml = re.sub(r"^( *)(- )", r"\1" + " " * indent + r"\2", yml, flags=re.MULTILINE)
            return f"---\n{yml}\n---\n"

        def _add_confluence_url_properties(self) -> None:
            mode = settings.export.confluence_url_in_frontmatter
            if mode == "none":
                return

            if mode in ("webui", "both") and self.page.web_url:
                key = sanitize_key("confluence_webui_url")
                if key not in self.page_properties:
                    self.page_properties[key] = self.page.web_url

            if mode in ("tinyui", "both") and self.page.tiny_url:
                key = sanitize_key("confluence_tinyui_url")
                if key not in self.page_properties:
                    self.page_properties[key] = self.page.tiny_url

        def _add_page_metadata_properties(self) -> None:
            if not settings.export.page_metadata_in_frontmatter:
                return

            page = self.page
            version = page.version
            history = page.history
            metadata = {
                # Stored as str to stay JS-safe-integer compatible: Confluence
                # Cloud page IDs can exceed 2^53, which JS-based SSGs (Hugo,
                # Astro, ...) parsing the front matter would silently truncate.
                "confluence_page_id": str(page.id),
                "confluence_space_key": page.space.key,
                "confluence_type": page.type,
                "confluence_created": history.created,
                "confluence_created_by": history.created_by.display_name,
                "confluence_last_modified": version.when,
                "confluence_last_modified_by": version.by.display_name,
                "confluence_version": version.number,
            }
            for raw_key, value in metadata.items():
                if value in (None, "", 0):
                    continue
                key = sanitize_key(raw_key)
                if key not in self.page_properties:
                    self.page_properties[key] = value

        @property
        def breadcrumbs(self) -> str:
            return (
                " > ".join(
                    [self.convert_page_link(ancestor.id) for ancestor in self.page.ancestors]
                )
                + "\n"
            )

        @property
        def labels(self) -> list[str]:
            return [label.name for label in self.page.labels]

        def set_page_properties(self, **props: list[str] | str | None) -> None:
            for key, value in props.items():
                if value:
                    self.page_properties[sanitize_key(key)] = value

        def convert_page_properties(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str | None:
            fmt = settings.export.page_properties_format

            if fmt == "table":
                return text

            rows = [
                cast("list[Tag]", tr.find_all(["th", "td"]))
                for tr in cast("list[Tag]", el.find_all("tr"))
                if tr
            ]
            if not rows:
                return None

            props: dict[str, str] = {}
            key_counts: dict[str, int] = {}
            for row in rows:
                if len(row) == 2:  # noqa: PLR2004
                    raw_key = row[0].get_text(strip=True)
                    count = key_counts.get(raw_key, 0) + 1
                    key_counts[raw_key] = count
                    unique_key = raw_key if count == 1 else f"{raw_key} {count}"
                    props[unique_key] = self.convert(str(row[1])).strip()

            if fmt in ("frontmatter", "frontmatter_and_table", "meta-bind-view-fields"):
                self.set_page_properties(**props)

            if fmt == "frontmatter":
                return None

            if fmt == "frontmatter_and_table":
                return text

            if fmt == "dataview-inline-field":
                lines = "\n".join(f"{k}:: {v}" for k, v in props.items())
                return f"\n{lines}\n"

            # meta-bind-view-fields: two-column table with VIEW fields in value column
            mode = settings.export.table_column_width
            rendered = _render_meta_bind_view_fields(props, mode)
            return f"\n{rendered}"

        def convert_alert(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert Confluence info macros to Markdown GitHub style alerts.

            GitHub specific alert types: https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#alerts

            Inside table cells GitHub alerts don't render in most viewers
            (Obsidian, etc.), so emit a leading emoji + plain text instead.
            """
            alert_type_map = {
                "info": "IMPORTANT",
                "panel": "NOTE",
                "tip": "TIP",
                "note": "WARNING",
                "warning": "CAUTION",
            }
            alert_emoji_map = {
                "NOTE": "\U0001f4dd",
                "TIP": "\U0001f4a1",
                "IMPORTANT": "❗",
                "WARNING": "⚠️",
                "CAUTION": "\U0001f6d1",
            }

            alert_type = alert_type_map.get(str(el["data-macro-name"]), "NOTE")

            macro_id = el.get("data-macro-id")
            custom_emoji = self._panel_icon_map.get(str(macro_id)) if macro_id else None
            emoji = custom_emoji or alert_emoji_map[alert_type]

            tags = parent_tags if isinstance(parent_tags, list | set) else set()
            if "td" in tags or "th" in tags:
                return f"{emoji} {text.strip()}"

            blockquote = super().convert_blockquote(el, text, parent_tags)
            return f"\n> [!{alert_type}]{blockquote}"

        def convert_div(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            # Handle Confluence macros
            if el.has_attr("data-macro-name"):
                macro_name = str(el["data-macro-name"])
                if macro_name in self.options["macros_to_ignore"]:
                    return ""

                macro_handlers = {
                    "panel": self.convert_alert,
                    "info": self.convert_alert,
                    "note": self.convert_alert,
                    "tip": self.convert_alert,
                    "warning": self.convert_alert,
                    "details": self.convert_page_properties,
                    "drawio": self.convert_drawio,
                    "gliffy": self.convert_gliffy,
                    "plantuml": self.convert_plantuml,
                    "plantumlcloud": self.convert_plantumlcloud,
                    "scroll-ignore": self.convert_hidden_content,
                    "toc": self.convert_toc,
                    "jira": self.convert_jira_table,
                    "attachments": self.convert_attachments,
                    "viewpdf": self.convert_viewpdf,
                    "markdown": self.convert_markdown,
                    "mohamicorp-markdown": self.convert_markdown,
                    "include": self.convert_include,
                    "excerpt-include": self.convert_include,
                    "content-tree": self.convert_pagetree,
                    "pagetree": self.convert_pagetree,
                    "children": self.convert_pagetree,
                }
                if macro_name in macro_handlers:
                    return macro_handlers[macro_name](el, text, parent_tags)

            class_handlers = {
                "expand-container": self.convert_expand_container,
                "columnLayout": self.convert_column_layout,
                "content-tree": self.convert_pagetree,
                "plugin_pagetree": self.convert_pagetree,
            }
            for class_name, handler in class_handlers.items():
                if class_name in str(el.get("class", "")):
                    return handler(el, text, parent_tags)

            return super().convert_div(el, text, parent_tags)

        def convert_expand_container(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            """Convert expand-container div to HTML details element."""
            # Extract summary text from expand-control-text
            summary_element = el.find("span", class_="expand-control-text")
            summary_text = (
                summary_element.get_text().strip() if summary_element else "Click here to expand..."
            )

            # Extract content from expand-content
            content_element = el.find("div", class_="expand-content")
            # Recursively convert the content
            content = (
                self.process_tag(content_element, parent_tags).strip() if content_element else ""
            )

            # Return as details element
            return f"\n<details>\n<summary>{summary_text}</summary>\n\n{content}\n\n</details>\n\n"

        def _span_highlight(self, style: str, text: str) -> str | None:
            bg_m = _RE_RGB_BG.search(style)
            if not bg_m:
                return None
            hex_color = _rgb_to_hex(int(bg_m.group(1)), int(bg_m.group(2)), int(bg_m.group(3)))
            return f'<mark style="background: {hex_color};">{text}</mark>'

        def _wrap_cell_highlight(self, el: BeautifulSoup, text: str) -> str:
            if not settings.export.convert_text_highlights:
                return text
            bg = _extract_cell_highlight_hex(el)
            if bg is None:
                return text
            inner = text or "&nbsp;"
            return f'<mark style="background: {bg};">{inner}</mark>'

        def convert_td(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            text = super().convert_td(el, text, parent_tags)
            return self._wrap_cell_highlight(el, text)

        def convert_th(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            text = super().convert_th(el, text, parent_tags)
            return self._wrap_cell_highlight(el, text)

        def _span_font_color(self, el: BeautifulSoup, style: str, text: str) -> str | None:
            color_m = _RE_RGB_COLOR.search(style)
            if color_m:
                hex_color = _rgb_to_hex(
                    int(color_m.group(1)), int(color_m.group(2)), int(color_m.group(3))
                )
                return f'<font style="color: {hex_color};">{text}</font>'
            color_id = el.get("data-colorid")
            if isinstance(color_id, str):
                hex_color = self._colorid_map.get(color_id)
                if hex_color:
                    return f'<font style="color: {hex_color};">{text}</font>'
            return None

        def _span_status_badge(self, el: BeautifulSoup, text: str) -> str | None:
            if not settings.export.convert_status_badges:
                return None
            classes = el.get("class") or []
            if not isinstance(classes, list):
                return None
            if "status-macro" not in classes:
                return None
            bg = "#dfe1e6"  # default gray
            for cls, color in _LOZENGE_COLORS.items():
                if cls in classes:
                    bg = color
                    break
            return f'<mark style="background: {bg};">{text.strip()}</mark>'

        def convert_span(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:  # noqa: C901, PLR0911
            if el.has_attr("data-macro-name"):
                if el["data-macro-name"] == "jira":
                    return self.convert_jira_issue(el, text, parent_tags)
                if el["data-macro-name"] == "status":
                    result = self._span_status_badge(el, text)
                    if result is not None:
                        return result
                if el["data-macro-name"] == "plantuml":
                    return self.convert_plantuml(el, text, parent_tags)

            if el.has_attr("class") and "inline-comment-marker" in el["class"]:
                return self.convert_inline_comment_marker(el, text, parent_tags)

            raw_style = el.get("style", "")
            style = raw_style if isinstance(raw_style, str) else ""
            if settings.export.convert_text_highlights:
                result = self._span_highlight(style, text)
                if result is not None:
                    return result

            if settings.export.convert_font_colors:
                result = self._span_font_color(el, style, text)
                if result is not None:
                    return result

            return text

        def convert_inline_comment_marker(
            self, el: BeautifulSoup, text: str, _parent_tags: list[str]
        ) -> str:
            if settings.export.comments_export in ("inline", "all"):
                ref = el.get("data-ref", "")
                if isinstance(ref, str) and ref and ref not in self._marked_texts:
                    self._marked_texts[ref] = text
            return text

        def convert_attachments(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            file_header = el.find("th", {"class": "filename-column"})
            file_header_text = file_header.text.strip() if file_header else "File"

            modified_header = el.find("th", {"class": "modified-column"})
            modified_header_text = modified_header.text.strip() if modified_header else "Modified"

            def _get_path(p: Path) -> str:
                attachment_path = self._get_path_for_href(p, settings.export.attachment_href)
                return attachment_path.replace(" ", "%20")

            def _attachment_link(att: Attachment) -> str:
                if settings.export.attachment_href == "wiki":
                    return f"[[{att.export_path.name}|{att.title}]]"
                return f"[{att.title}]({_get_path(att.export_path)})"

            rows = [
                {
                    "file": _attachment_link(att),
                    "modified": f"{att.version.friendly_when} by {self.convert_user(att.version.by)}",  # noqa: E501
                }
                for att in self.page.attachments
            ]

            html = f"""<table>
            <tr><th>{file_header_text}</th><th>{modified_header_text}</th></tr>
            {"".join(f"<tr><td>{row['file']}</td><td>{row['modified']}</td></tr>" for row in rows)}
            </table>"""

            return (
                f"\n\n{self.convert_table(BeautifulSoup(html, 'html.parser'), text, parent_tags)}\n"
            )

        def convert_column_layout(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            """Render a Confluence column layout by stacking its cells vertically.

            Markdown has no native columns, so each cell's content is converted
            through its normal block-level handlers and the cells are joined
            vertically. This preserves images, lists, tables and the TOC, which
            a single-row table would otherwise flatten or drop.
            """
            # recursive=False so a nested column layout's cells are not also
            # collected here; they are rendered when process_tag recurses into
            # the parent cell. Cells are always direct children of columnLayout.
            cells = el.find_all("div", {"class": "cell"}, recursive=False)
            if not cells:
                return super().convert_div(el, text, parent_tags)

            parts = [self.process_tag(cell, parent_tags).strip() for cell in cells]
            parts = [part for part in parts if part]
            if not parts:
                return ""

            return "\n\n" + "\n\n".join(parts) + "\n\n"

        def convert_jira_table(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            jira_tables = BeautifulSoup(self.page.body_export, "html.parser").find_all(
                "div", {"class": "jira-table"}
            )

            if len(jira_tables) == 0:
                logger.warning("No Jira table found. Ignoring.")
                return text

            if len(jira_tables) > 1:
                logger.exception("Multiple Jira tables are not supported. Ignoring.")
                return text

            return self.process_tag(jira_tables[0], parent_tags)

        def convert_toc(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            if not settings.export.include_toc:
                return ""

            tocs = BeautifulSoup(self.page.body_export, "html.parser").find_all(
                "div", {"class": "toc-macro"}
            )

            if len(tocs) == 0:
                logger.warning("Could not find TOC macro. Ignoring.")
                return text

            if len(tocs) > 1:
                logger.exception("Multiple TOC macros are not supported. Ignoring.")
                return text

            return self.process_tag(tocs[0], parent_tags)

        def convert_pagetree(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert a Confluence content-tree / page-tree macro to nested page links.

            The macro renders as an empty JavaScript placeholder in ``body.view``, so its
            child pages are resolved from the API (``Page.descendants``) and emitted as a
            nested Markdown bullet list. Honors the ``root`` (``@self`` / ``@home`` / a page
            title) and tree-depth parameters read from the storage-format XML. Children are
            ordered by title, since Confluence's manual "position" order is not available via
            the CQL descendants query.
            """
            params = self._extract_pagetree_params(el)
            root_page = self._resolve_pagetree_root(
                params.get("root"), params.get("root_space_key")
            )
            if root_page is None:
                return ""

            max_depth = self._pagetree_depth(params)
            if max_depth is None and str(el.get("data-macro-name", "")) == "children":
                # The Children Display macro shows only direct children unless `all=true`.
                if params.get("all", "").strip().lower() != "true":
                    max_depth = 1
            cache_key = (root_page.id, max_depth)
            descendants = self._pagetree_descendants_cache.get(cache_key)
            if descendants is None:
                if max_depth is None or max_depth > 2:  # noqa: PLR2004
                    # Broad OR queries cost more than one subtree query for deep trees.
                    descendants = root_page.descendants
                else:
                    # A shallow tree must not fetch thousands of hidden descendants.
                    descendants = []
                    parents = [root_page.id]
                    for _ in range(max_depth):
                        level = []
                        for start in range(0, len(parents), 100):
                            parents_cql = " OR ".join(
                                f"parent={parent_id}" for parent_id in parents[start : start + 100]
                            )
                            level.extend(
                                _search_pages(f"type=page AND ({parents_cql})", root_page.base_url)
                            )
                        descendants.extend(level)
                        parents = [page.id for page in level]
                        if not parents:
                            break
                self._pagetree_descendants_cache[cache_key] = descendants
            lines = self._render_pagetree(root_page.id, descendants, max_depth)
            if not lines:
                return ""
            return "\n" + "\n".join(lines) + "\n\n"

        _PAGETREE_MACRO_NAMES: ClassVar[set[str]] = {"content-tree", "pagetree", "children"}

        def _extract_pagetree_params(self, el: BeautifulSoup) -> dict[str, str]:
            """Read the content-tree macro parameters from the storage-format XML.

            BeautifulSoup with the ``xml`` parser strips namespace prefixes, so
            ``ac:structured-macro`` becomes ``structured-macro`` and ``ac:parameter``
            becomes ``parameter``. The macro is matched by ``macro-id`` when the rendered
            div carries one; otherwise the first matching macro is used (class-triggered
            fallback path).
            """
            source = self.page.editor2 or self.page.body_storage
            if not source:
                return {}

            macro_id = el.get("data-macro-id")
            soup = BeautifulSoup(f"<root>{source}</root>", "xml")
            found_any = False
            for macro in soup.find_all("structured-macro"):
                if not isinstance(macro, Tag):
                    continue
                if macro.get("name") not in self._PAGETREE_MACRO_NAMES:
                    continue
                found_any = True
                if macro_id and macro.get("macro-id") != macro_id:
                    continue
                return self._read_macro_params(macro)
            if macro_id and found_any:
                logger.warning(
                    "Content tree macro (macro-id '%s') not found in storage XML; "
                    "falling back to defaults.",
                    macro_id,
                )
            return {}

        @staticmethod
        def _read_macro_params(macro: Tag) -> dict[str, str]:
            """Read a structured-macro's direct ``parameter`` children into a dict."""
            params: dict[str, str] = {}
            for p in macro.find_all("parameter", recursive=False):
                if not isinstance(p, Tag):
                    continue
                name = p.get("name")
                if not name:
                    continue
                # Page-reference params (e.g. `root`) carry their value in a nested
                # `ri:page` `ri:content-title` attribute rather than as element text; the
                # referenced page may live in another space (`ri:space-key`).
                ri_page = p.find("page")
                if isinstance(ri_page, Tag) and ri_page.get("content-title"):
                    params[str(name)] = str(ri_page.get("content-title"))
                    space_key = ri_page.get("space-key")
                    if space_key:
                        params[f"{name}_space_key"] = str(space_key)
                else:
                    params[str(name)] = p.get_text(strip=True)
            return params

        @staticmethod
        def _pagetree_depth(params: dict[str, str]) -> int | None:
            """Return the number of levels to render, or ``None`` for the full subtree.

            ``depth`` (Children Display macro) expresses the number of levels directly, so
            it is preferred; ``startDepth`` (Page Tree macro) maps to the same UI "Tree
            depth" field on the instances observed and is used as a fallback.
            """
            for key in ("depth", "expandDepth", "startDepth"):
                value = params.get(key)
                if not value:
                    continue
                try:
                    depth = int(value)
                except ValueError:
                    continue
                if depth > 0:
                    return depth
            return None

        def _resolve_pagetree_root(
            self, root_value: str | None, space_key: str | None = None
        ) -> "Page | None":
            """Resolve the tree root to a Page (``@self`` / ``@home`` / a page title).

            ``space_key`` is the space of a title-referenced root page (from the macro's
            ``ri:page`` ``ri:space-key``); when absent the current page's space is used.
            """
            root = (root_value or "").strip()
            if not root or root == "@self":
                return self.page
            if root == "@home":
                homepage_id = self.page.space.homepage
                if not homepage_id:
                    logger.warning(
                        "Content tree macro root is @home but space '%s' has no homepage; "
                        "skipping.",
                        self.page.space.key,
                    )
                    return None
                return Page.from_id(homepage_id, self.page.base_url)

            page_id = self._find_page_id_by_title(root, space_key)
            if page_id is None:
                logger.warning(
                    "Content tree macro root page '%s' could not be resolved; skipping.", root
                )
                return None
            return Page.from_id(page_id, self.page.base_url)

        def _find_page_id_by_title(self, title: str, space_key: str | None = None) -> int | None:
            """Resolve a page id by exact title within a space via CQL (best effort)."""
            client = get_thread_confluence(self.page.base_url)
            space = space_key or self.page.space.key

            def _escape(value: str) -> str:
                return value.replace("\\", "\\\\").replace('"', '\\"')

            cql = f'type=page AND space="{_escape(space)}" AND title="{_escape(title)}"'
            try:
                response = cast(
                    "dict",
                    client.get("rest/api/content/search", params={"cql": cql, "limit": 1}),
                )
            except Exception:
                logger.exception("Failed to resolve content tree root page '%s'.", title)
                return None
            results = response.get("results", [])
            if not results:
                return None
            # CQL title matching can be fuzzy; require an exact title match to be safe.
            first = results[0]
            if first.get("title") != title:
                return None
            try:
                return int(first.get("id"))
            except (TypeError, ValueError):
                return None

        def _render_pagetree(
            self, root_id: int, descendants: list["Descendant"], max_depth: int | None
        ) -> list[str]:
            """Build a nested bullet list of page links from the root's descendants."""
            children_by_parent: dict[int, list[Descendant]] = {}
            for descendant in descendants:
                if not descendant.id:
                    continue
                # `Descendant.from_json` strips only the topmost ancestor, so the last
                # ancestor is the descendant's immediate parent.
                parent_id = descendant.ancestors[-1].id if descendant.ancestors else root_id
                children_by_parent.setdefault(parent_id, []).append(descendant)

            lines: list[str] = []

            def walk(parent_id: int, level: int) -> None:
                if max_depth is not None and level >= max_depth:
                    return
                for child in sorted(children_by_parent.get(parent_id, []), key=lambda c: c.title):
                    lines.append(f"{'  ' * level}- {self.convert_page_link(child.id, page=child)}")
                    walk(child.id, level + 1)

            walk(root_id, 0)
            return lines

        def convert_hidden_content(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            content = super().convert_p(el, text, parent_tags)
            if not content.strip():
                return ""
            return f"\n<!--{content}-->\n"

        def convert_jira_issue(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            issue_key = el.get("data-jira-key")
            link = cast("BeautifulSoup", el.find("a", {"class": "jira-issue-key"}))
            if not link:
                return text
            if not issue_key:
                return self.process_tag(link, parent_tags)

            try:
                jira_url = _extract_jira_base_url(str(link.get("href", ""))) or self.page.base_url
                issue = (
                    JiraIssue.from_key(str(issue_key), jira_url)
                    if settings.export.enable_jira_enrichment
                    else None
                )
            except HTTPError:
                return f"[[{issue_key}]]({link.get('href')})"

            if not issue:
                return f"[[{issue_key}]]({link.get('href')})"

            issue_status = " ".join(issue.status.split())
            issue_status = (
                issue_status.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")
            )
            status = (
                f" ({issue_status})" if settings.export.include_jira_status and issue_status else ""
            )
            return f"[[{issue.key}] {issue.summary}{status}]({link.get('href')})"

        def convert_pre(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:  # type: ignore[override]
            if not text:
                return ""

            code_language = ""
            if el.has_attr("data-syntaxhighlighter-params"):
                match = re.search(r"brush:\s*([^;]+)", str(el["data-syntaxhighlighter-params"]))
                if match:
                    code_language = match.group(1)

            if "@startuml" in text:
                code_language = "plantuml"

            return f"\n\n```{code_language}\n{text}\n```\n\n"

        def convert_sub(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            return f"<sub>{text}</sub>"

        def convert_sup(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert superscript to Markdown footnotes."""
            if el.previous_sibling is None:
                return f"[^{text}]:"  # Footnote definition
            return f"[^{text}]"  # f"<sup>{text}</sup>"

        def convert_a(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:  # noqa: PLR0911, PLR0912, C901
            if "user-mention" in str(el.get("class")):
                return self.convert_user_mention(el, text, parent_tags)
            if "createpage.action" in str(el.get("href")) or "createlink" in str(el.get("class")):
                logger.warning(
                    f"Broken link detected: '{text}' on page '{self.page.title}' "
                    f"(ID: {self.page.id}). This is likely a Confluence bug. "
                    f"Please report this issue to Atlassian Support."
                )
                # Find fallback link without using string= parameter to avoid
                # BeautifulSoup recursion bug. The string= parameter triggers
                # recursive .string property access which fails on Fabric
                # Editor v2 HTML with fab:media tags
                try:
                    soup = BeautifulSoup(self.page.editor2, "html.parser")
                    for link in soup.find_all("a"):
                        # Use get_text() instead of .string to avoid recursion issues
                        link_text = link.get_text(strip=True)
                        if link_text == text:
                            # Prevent infinite recursion if fallback is the same element
                            if isinstance(link, Tag) and link.get("href") != el.get("href"):
                                return self.convert_a(link, text, parent_tags)  # type: ignore[arg-type]
                except RecursionError:
                    # editor2 HTML contains problematic tags (e.g., fab:media)
                    # that cause BS4 recursion. Skip fallback and return
                    # wiki-style link
                    pass
                # If no matching link found, return wiki-style link
                return f"[[{text}]]"
            if "page" in str(el.get("data-linked-resource-type")):
                page_id = str(el.get("data-linked-resource-id", ""))
                if page_id and page_id != "null":
                    return self.convert_page_link(int(page_id), text)
            if "attachment" in str(el.get("data-linked-resource-type")):
                link = self.convert_attachment_link(el, text, parent_tags)
                # convert_attachment_link may return None if the attachment meta is incomplete
                return link or f"[{text}]({el.get('href')})"
            href_str = str(el.get("href", ""))
            if href_str and (attachment := self._attachment_from_download_href(href_str)):
                return self._format_attachment_link(attachment)
            if href_str:
                parsed_href = urlparse(href_str)
                base_host = urlparse(getattr(self.page, "base_url", "") or "").hostname
                if not parsed_href.hostname or parsed_href.hostname == base_host:
                    query_params = urllib.parse.parse_qs(parsed_href.query)
                    page_id_param = next(
                        (
                            values[0]
                            for key, values in query_params.items()
                            if key.lower() == "pageid" and values and values[0]
                        ),
                        None,
                    )
                    # A bare URL as anchor text carries no author intent; let the
                    # target page title label the link instead.
                    label = "" if text.strip() == href_str.strip() else text
                    if page_id_param and page_id_param.isdigit():
                        return self.convert_page_link(int(page_id_param), label)
                    if match := parse_confluence_path(parsed_href.path):
                        page_id = match.page_id
                        if not page_id and match.space_key and match.page_title:
                            page_id = _page_id_by_title(
                                match.space_key, match.page_title, self.page.base_url
                            )
                        if page_id:
                            return self.convert_page_link(page_id, label)
            if (href := href_str).startswith("#"):
                if settings.export.page_href == "wiki":
                    return f"[[#{text}]]"
                return f"[{text}](#{github_heading_slug(href[1:])})"

            if href_str and text.replace(r"\_", "_") != href_str:
                # Parentheses and spaces in the destination end a Markdown link
                # early (e.g. Kibana URLs with `?_g=()`). Percent-encode them.
                el["href"] = href_str.replace(" ", "%20").replace("(", "%28").replace(")", "%29")
                # A URL used as link text needs no escaping of its underscores.
                if text.startswith(("http://", "https://")):
                    text = text.replace(r"\_", "_")

            return super().convert_a(el, text, parent_tags)

        def convert_page_link(
            self, page_id: int, text: str = "", page: Descendant | None = None
        ) -> str:
            """Render a link to another page.

            ``text`` is the anchor text as it appears on the source page. Confluence
            authors routinely adjust it (plural forms, declension, shorter labels);
            keep it and only fall back to the target page title when it is empty.
            """
            if not page_id:
                msg = "Page link does not have valid page_id."
                raise ValueError(msg)

            page = _link_target(page_id, self.page.base_url) if page is None else page

            if page is None or page.title == "Page not accessible":
                logger.warning(
                    f"Confluence page link (ID: {page_id}) is not accessible, "
                    f"referenced from page '{self.page.title}' (ID: {self.page.id})"
                )
                return f"[Page not accessible (ID: {page_id})]"

            label = text.strip() or page.title

            ancestor_gate = settings.export.page_href_relative_only_if_ancestor_of
            if isinstance(ancestor_gate, int):
                ancestors_ids = {anc.id for anc in page.ancestors} | {page.id}
                if ancestor_gate not in ancestors_ids:
                    return f"[{label}]({page.web_url})"

            PageTitleRegistry.register(int(page.id), page.title)

            if settings.export.page_href == "wiki":
                # Wiki aliases are shown verbatim, so drop the Markdown escapes
                # markdownify added to the anchor text (e.g. "my\\_page").
                label = re.sub(r"\\([_*])", r"\1", label)
                if PageTitleRegistry.is_ambiguous(page.title):
                    vault_path = page.export_path.with_suffix("").as_posix()
                    return f"[[{vault_path}|{label}]]"
                if label != page.title:
                    return f"[[{page.title}|{label}]]"
                return f"[[{page.title}]]"

            page_path = self._get_path_for_href(page.export_path, settings.export.page_href)
            return f"[{label}]({page_path.replace(' ', '%20')})"

        def _format_attachment_link(self, attachment: Attachment) -> str:
            if settings.export.attachment_href == "wiki":
                return f"[[{attachment.export_path.name}|{attachment.title}]]"

            path = self._get_path_for_href(attachment.export_path, settings.export.attachment_href)
            return f"[{attachment.title}]({path.replace(' ', '%20')})"

        def _attachment_from_download_href(self, href: str) -> Attachment | None:
            parsed = urlparse(href)
            path_parts = [unquote(part) for part in parsed.path.split("/") if part]
            try:
                filename = path_parts[path_parts.index("attachments") + 2]
            except (ValueError, IndexError):
                return None

            matches = self.page.get_attachments_by_title(filename)
            return matches[0] if matches else None

        def convert_attachment_link(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            """Build a Markdown link for an attachment.

            If the attachment metadata is missing,
            return the original Confluence URL instead of crashing.
            """
            attachment = None
            if fid := el.get("data-linked-resource-file-id"):
                attachment = self.page.get_attachment_by_file_id(str(fid))
            if not attachment and (fid := el.get("data-media-id")):
                attachment = self.page.get_attachment_by_file_id(str(fid))
            if not attachment and (aid := el.get("data-linked-resource-id")):
                attachment = self.page.get_attachment_by_id(str(aid))
            if not attachment and (href := el.get("href")):
                attachment = self._attachment_from_download_href(str(href))

            if attachment is None:
                href = el.get("href") or text
                return f"[{text}]({href})"

            return self._format_attachment_link(attachment)

        def convert_viewpdf(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert the PDF/file preview macro (`viewpdf`) to a Markdown attachment link.

            The macro renders as a clientside preview widget with no static link in
            body.view/body.export_view, but the wrapping element carries the referenced
            attachment as `data-attachment-id`/`data-attachment` (URL-encoded filename).
            """
            attachment = None
            if aid := el.get("data-attachment-id"):
                attachment = self.page.get_attachment_by_id(str(aid))
            if not attachment and (raw_filename := el.get("data-attachment")):
                matches = self.page.get_attachments_by_title(unquote_plus(str(raw_filename)))
                attachment = matches[0] if matches else None

            if attachment is None:
                return "\n<!-- viewpdf macro: attachment not found -->\n\n"

            return f"\n{self._format_attachment_link(attachment)}\n\n"

        def convert_time(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            if el.has_attr("datetime"):
                return f"{el['datetime']}"

            return f"{text}"

        def convert_user_mention(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            if aid := el.get("data-account-id"):
                try:
                    return self.convert_user(User.from_accountid(str(aid), self.page.base_url))
                except ApiNotFoundError:
                    logger.warning(f"User {aid} not found. Using text instead.")

            return self.convert_user_name(text)

        def convert_user(self, user: User) -> str:
            return self.convert_user_name(user.display_name)

        def convert_user_name(self, name: str) -> str:
            return name.removesuffix("(Unlicensed)").removesuffix("(Deactivated)").strip()

        def convert_li(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            md = super().convert_li(el, text, parent_tags)
            bullet = self.options["bullets"][0]

            # Convert Confluence task lists to GitHub task lists
            if el.has_attr("data-inline-task-id"):
                is_checked = el.has_attr("class") and "checked" in el["class"]
                return md.replace(f"{bullet} ", f"{bullet} {'[x]' if is_checked else '[ ]'} ", 1)

            return md

        _ATLASSIAN_EMOTICONS: ClassVar[dict[str, str]] = {
            "atlassian-check_mark": "✅",
            "atlassian-cross_mark": "❌",
            "atlassian-yes": "👍",
            "atlassian-no": "👎",
            "atlassian-information": "\u2139\ufe0f",
            "atlassian-warning": "⚠️",
            "atlassian-forbidden": "🚫",
            "atlassian-plus": "\u2795",
            "atlassian-minus": "\u2796",
            "atlassian-question": "❓",
            "atlassian-exclamation": "❗",
            "atlassian-light_on": "💡",
            "atlassian-light_off": "💡",
            "atlassian-star_yellow": "⭐",
            "atlassian-blue_star": "🔵",
            "atlassian-smile": "😊",
            "atlassian-sad": "😞",
            "atlassian-tongue": "😛",
            "atlassian-biggrin": "😁",
            "atlassian-wink": "😉",
        }

        # Server/DC emoticons carry `data-emoticon-name` instead of the Cloud
        # `data-emoji-*` attributes. Keys are Confluence's built-in emoticon names.
        _EMOTICON_SERVERDC_NAMES: ClassVar[dict[str, str]] = {
            "smile": "😊",
            "sad": "😞",
            "cheeky": "😛",
            "laugh": "😁",
            "wink": "😉",
            "thumbs-up": "👍",
            "thumbs-down": "👎",
            "yes": "👍",
            "no": "👎",
            "information": "\u2139\ufe0f",
            "tick": "✅",
            "cross": "❌",
            "warning": "⚠️",
            "plus": "\u2795",
            "minus": "\u2796",
            "question": "❓",
            "light-on": "💡",
            "light-off": "💡",
            "yellow-star": "⭐",
            "red-star": "⭐",
            "green-star": "⭐",
            "blue-star": "⭐",
            "heart": "❤️",
            "broken-heart": "💔",
        }

        def _convert_emoticon(self, el: BeautifulSoup) -> str | None:
            classes = el.get("class") or []
            if "emoticon" not in classes:
                return None

            # Try Cloud format first (data-emoji-id, data-emoji-fallback, etc.)
            emoji_id = str(el.get("data-emoji-id", ""))
            fallback = str(el.get("data-emoji-fallback", ""))
            if fallback and not fallback.startswith(":"):
                return fallback
            if emoji_id:
                try:
                    codepoints = [int(cp, 16) for cp in emoji_id.split("-")]
                    if all(0 <= cp <= _MAX_UNICODE_CODEPOINT for cp in codepoints):
                        return "".join(chr(cp) for cp in codepoints)
                except (OverflowError, ValueError):
                    pass
                if emoji_id in self._ATLASSIAN_EMOTICONS:
                    return self._ATLASSIAN_EMOTICONS[emoji_id]
            shortname = str(el.get("data-emoji-shortname", ""))

            # Fallback to Server/DC format (data-emoticon-name)
            emoticon_name = str(el.get("data-emoticon-name", ""))
            if emoticon_name in self._EMOTICON_SERVERDC_NAMES:
                return self._EMOTICON_SERVERDC_NAMES[emoticon_name]

            return shortname or fallback or str(el.get("alt", "")) or None

        def convert_img(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:  # noqa: C901, PLR0911, PLR0912
            if emoticon := self._convert_emoticon(el):
                return emoticon

            attachment = None
            if fid := el.get("data-media-id"):
                attachment = self.page.get_attachment_by_file_id(str(fid))
            if not attachment and (fid := el.get("data-media-id")):
                attachment = self.page.get_attachment_by_file_id(str(fid))
            if not attachment and (fid := el.get("data-linked-resource-file-id")):
                attachment = self.page.get_attachment_by_file_id(str(fid))
            if not attachment and (aid := el.get("data-linked-resource-id")):
                attachment = self.page.get_attachment_by_id(str(aid))
            if not attachment and (encoded_xml := el.get("data-encoded-xml")):
                decoded = unquote(str(encoded_xml))
                if m := re.search(r'ri:filename="([^"]+)"', decoded):
                    matches = self.page.get_attachments_by_title(m.group(1))
                    if matches:
                        attachment = matches[0]

            url_src = str(el.get("src", ""))

            if ".drawio.png" in url_src:
                filename = unquote(urlparse(url_src).path.split("/")[-1])
                drawio_result = self._convert_drawio_embedded_mermaid(filename)
                if drawio_result:
                    return drawio_result
                # If no mermaid diagram extracted, use PNG as attachment fallback
                if attachment is None:
                    drawio_images = self.page.get_attachments_by_title(filename)
                    if len(drawio_images) > 0:
                        attachment = drawio_images[0]

            # Confluence occasionally emits embedded images with no data-media identifiers at
            # all, leaving the download URL as the only link back to the attachment.
            # Resolve those by filename so they are exported as local files instead
            # of an absolute Confluence URL.
            if attachment is None:
                for candidate in (url_src, str(el.get("data-image-src", ""))):
                    if candidate:
                        attachment = self._attachment_from_download_href(candidate)
                        if attachment is not None:
                            break

            if attachment is None:
                href = el.get("href") or text
                if href:
                    return f"![{text}]({href})"
                if url_src:
                    return f"![{text}]({url_src})"
                return text

            caption = (
                self._image_captions.get(attachment.title, "")
                if settings.export.image_captions
                else ""
            )

            data_uri = self._image_data_uri(attachment) if settings.export.embed_images else None

            if settings.export.attachment_href == "wiki" and not data_uri:
                img_md = f"![[{attachment.export_path.name}]]"
                return f"{img_md}\n*{caption}*" if caption else img_md

            if data_uri:
                el["src"] = data_uri
            else:
                path = self._get_path_for_href(
                    attachment.export_path, settings.export.attachment_href
                )
                el["src"] = path.replace(" ", "%20")
            tags = parent_tags if isinstance(parent_tags, list | set) else set()
            if "_inline" in tags:
                tags = set(tags)
                tags.discard("_inline")  # Always show images.
            img_md = super().convert_img(el, text, tags)  # type: ignore[union-attr]
            return f"{img_md}\n*{caption}*" if caption else img_md

        @staticmethod
        def _image_data_uri(attachment: Attachment) -> str | None:
            """Return the downloaded image as a base64 data URI, or None."""
            if not attachment.media_type.startswith("image/"):
                return None
            try:
                data = (settings.export.output_path / attachment.export_path).read_bytes()
            except OSError:
                logger.debug("Cannot embed '%s': file not downloaded", attachment.title)
                return None
            return f"data:{attachment.media_type};base64,{base64.b64encode(data).decode()}"

        def _normalize_unicode_whitespace(self, text: str) -> str:
            r"""Normalize Unicode whitespace to regular spaces.

            This fixes an issue where markdownify's chomp() function strips Unicode
            whitespace characters (like \xa0 from &nbsp;) entirely, causing missing
            spaces in markdown output.

            Confluence often uses &nbsp; (non-breaking space, \xa0) inside inline
            formatting tags like <em>&nbsp;text</em>. BeautifulSoup correctly converts
            this to \xa0, but markdownify's chomp() doesn't preserve it, resulting in
            output like "word*text*" instead of "word *text*".

            This method normalizes all Unicode whitespace characters to regular ASCII
            spaces so they are preserved by markdownify's chomp() function.

            Args:
                text: Text string to normalize

            Returns:
                Text with Unicode whitespace replaced by regular spaces
            """
            # Normalize all Unicode whitespace to regular space
            # This includes: \xa0 (nbsp), \u2000-\u200a (various spaces),
            # \u2028 (line separator), \u2029 (paragraph separator), etc.
            # Keep \n, \r, \t as-is since they have semantic meaning
            normalized = text
            for char in text:
                if char.isspace() and char not in " \n\r\t":
                    # Replace Unicode whitespace with regular space
                    normalized = normalized.replace(char, " ")
            return normalized

        def escape(self, text: str, parent_tags: list[str]) -> str:
            escaped: str = cast("Any", MarkdownConverter).escape(self, text, parent_tags)
            return escaped.replace("[", r"\[").replace("]", r"\]")

        def _escape_template_placeholders(self, text: str) -> str:
            r"""Escape <placeholder> patterns that Obsidian misparsed as HTML tags.

            Confluence templates use <placeholder text> to mark values that need
            replacing. Obsidian's renderer treats these as HTML, breaking page
            formatting. This method escapes them to \<placeholder text\> so they
            render as literal angle-bracket text.

            Valid HTML tags (e.g. <br/>) are preserved. Content inside fenced code
            blocks and inline code spans is left untouched.
            """

            def _escape_if_placeholder(m: re.Match) -> str:
                inner = m.group(1)
                if _AUTOLINK_URI_RE.match(inner) or _AUTOLINK_EMAIL_RE.match(inner):
                    return m.group(0)
                # Strip leading slash (closing tag), get first token, strip trailing slash
                stripped = inner.strip().lstrip("/")
                tag_name = re.split(r"[\s/]", stripped)[0].lower() if stripped else ""
                if tag_name in _HTML_ELEMENTS or inner.startswith("!"):
                    return m.group(0)
                return f"\\<{inner}\\>"

            lines = text.split("\n")
            result = []
            in_fence = False
            for line in lines:
                if _CODE_FENCE_RE.match(line):
                    in_fence = not in_fence
                    result.append(line)
                    continue
                if in_fence:
                    result.append(line)
                    continue
                # Interleave non-code and inline-code parts; only process non-code
                parts = _INLINE_CODE_RE.split(line)
                codes = _INLINE_CODE_RE.findall(line)
                processed = []
                for i, part in enumerate(parts):
                    processed.append(_ANGLE_BRACKET_RE.sub(_escape_if_placeholder, part))
                    if i < len(codes):
                        processed.append(codes[i])
                result.append("".join(processed))
            return "\n".join(result)

        def convert_em(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert <em> tags, preserving spaces from Unicode whitespace entities."""
            text = self._normalize_unicode_whitespace(text)
            return super().convert_em(el, text, parent_tags)

        def convert_strong(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert <strong> tags, preserving spaces from Unicode whitespace entities."""
            text = self._normalize_unicode_whitespace(text)
            stripped = text.strip()
            # Punctuation at either edge can prevent Markdown emphasis delimiters from matching.
            if stripped and "_noformat" not in parent_tags and any(
                unicodedata.category(char).startswith(("P", "S"))
                for char in (stripped[0], stripped[-1])
            ):
                return f"<strong>{text}</strong>"
            return super().convert_strong(el, text, parent_tags)

        def convert_code(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert <code> tags, preserving spaces from Unicode whitespace entities."""
            text = self._normalize_unicode_whitespace(text)
            return super().convert_code(el, text, parent_tags)

        def convert_i(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert <i> tags, preserving spaces from Unicode whitespace entities."""
            text = self._normalize_unicode_whitespace(text)
            return super().convert_i(el, text, parent_tags)

        def convert_b(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert <b> tags, preserving spaces from Unicode whitespace entities."""
            return self.convert_strong(el, text, parent_tags)

        def _convert_drawio_embedded_mermaid(self, filename: str) -> str | None:
            """Extract mermaid diagram from DrawIO PNG preview image.

            Args:
                filename: The filename of the drawio diagram image.

            Returns:
                Markdown formatted mermaid diagram or None if not found.
            """
            drawio_title = filename.removesuffix(".png")
            drawio_attachments = self.page.get_attachments_by_title(drawio_title)

            if len(drawio_attachments) == 0:
                return None

            drawio_filepath = settings.export.output_path / drawio_attachments[0].export_path
            if not drawio_filepath.exists():
                return None

            # Extract mermaid diagram from DrawIO file
            return load_and_parse_drawio(str(drawio_filepath))

        def _extract_macro_param_from_storage(
            self, el: BeautifulSoup, macro_name: str, param_name: str
        ) -> str | None:
            """Read a macro parameter from body.storage for a rendered macro element.

            The storage macro is matched by macro-id when the view carries one,
            otherwise by the element's position among same-class view elements.
            """
            storage_macros = self._storage_macros_by_name(macro_name)
            if not storage_macros:
                return None

            macro_id = el.get("data-macro-id")
            if not macro_id:
                child = el.find(attrs={"data-macroid": True})
                if isinstance(child, Tag):
                    macro_id = child.get("data-macroid")

            target = None
            if macro_id:
                target = next((m for m in storage_macros if m.get("macro-id") == macro_id), None)
            if target is None:
                view_soup = BeautifulSoup(self.page.body_view or "", "html.parser")
                view_elements = view_soup.find_all(el.name, class_=el.get("class"))
                if el in view_elements:
                    idx = view_elements.index(el)
                    if idx < len(storage_macros):
                        target = storage_macros[idx]
            if target is None:
                return None

            param = target.find("parameter", {"name": param_name})
            return param.get_text(strip=True) if isinstance(param, Tag) else None

        def convert_drawio(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert DrawIO diagrams to markdown image/file links.

            Supports two strategies:
            1. Cloud/editor2 format: Extract from HTML pattern `|diagramName=....|`
            2. Server/DC fallback: Parse from body.storage structured-macros
            """
            # Strategy 1: Cloud format
            drawio_name = None
            if match := re.search(r"\|diagramName=(.+?)\|", str(el)):
                drawio_name = match.group(1)

            # Strategy 2: Server/DC fallback
            if not drawio_name:
                drawio_name = self._extract_macro_param_from_storage(el, "drawio", "diagramName")

            if not drawio_name:
                return ""

            # Find and render attachments
            preview_name = f"{drawio_name}.png"
            drawio_attachments = self.page.get_attachments_by_title(drawio_name)
            preview_attachments = self.page.get_attachments_by_title(preview_name)

            if not drawio_attachments or not preview_attachments:
                return f"\n<!-- DrawIO diagram `{drawio_name}` not found -->\n\n"

            # Render based on href setting
            if settings.export.attachment_href == "wiki":
                preview_filename = preview_attachments[0].export_path.name
                drawio_filename = drawio_attachments[0].export_path.name
                drawio_image_embedding = f"![[{preview_filename}|{drawio_name}]]"
                drawio_link = f"[[{drawio_filename}|{drawio_image_embedding}]]"
            else:
                drawio_path = self._get_path_for_href(
                    drawio_attachments[0].export_path, settings.export.attachment_href
                )
                preview_path = self._get_path_for_href(
                    preview_attachments[0].export_path, settings.export.attachment_href
                )
                drawio_image_embedding = f"![{drawio_name}]({preview_path.replace(' ', '%20')})"
                drawio_link = f"[{drawio_image_embedding}]({drawio_path.replace(' ', '%20')})"
            return f"\n{drawio_link}\n\n"

        def convert_gliffy(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert Gliffy diagrams to markdown image links.

            On Confluence Server/DC, Gliffy macros render clientside in body.view but
            the metadata is available in body.storage. This handler extracts diagram names
            from storage and renders them as markdown image links.

            Args:
                el: The div element containing the macro
                text: The processed text content
                parent_tags: Stack of parent HTML tags

            Returns:
                Markdown formatted image link or error comment
            """
            # Try to extract diagram name from storage
            gliffy_name = self._extract_macro_param_from_storage(el, "gliffy", "diagramName")

            if not gliffy_name:
                return "\n<!-- Gliffy diagram not found (no diagramName in storage) -->\n\n"

            # Find preview image attachment
            preview_name = f"{gliffy_name}.png"
            preview_attachments = self.page.get_attachments_by_title(preview_name)

            if not preview_attachments:
                return f"\n<!-- Gliffy diagram `{gliffy_name}` preview image not found -->\n\n"

            # Render as markdown image link
            if settings.export.attachment_href == "wiki":
                preview_filename = preview_attachments[0].export_path.name
                return f"\n![[{preview_filename}|{gliffy_name}]]\n\n"
            preview_path = self._get_path_for_href(
                preview_attachments[0].export_path, settings.export.attachment_href
            )
            return f"\n![{gliffy_name}]({preview_path.replace(' ', '%20')})\n\n"

        def _extract_uml_from_editor2(self, macro_id: str) -> str | None:
            """Extract PlantUML source from editor2 XML by macro-id (Cloud format)."""
            if not self.page.editor2:
                return None
            wrapped = f"<root>{self.page.editor2}</root>"
            soup = BeautifulSoup(wrapped, "xml")
            for macro in soup.find_all("structured-macro"):
                if not isinstance(macro, Tag):
                    continue
                if macro.get("name") != "plantuml" or macro.get("macro-id") != macro_id:
                    continue
                plain_text_body = macro.find("plain-text-body")
                if not isinstance(plain_text_body, Tag):
                    continue
                cdata = plain_text_body.get_text(strip=True)
                if not cdata:
                    continue
                try:
                    return json.loads(cdata).get("umlDefinition") or None
                except json.JSONDecodeError:
                    return None
            return None

        def _extract_uml_from_storage(self) -> str | None:
            """Extract PlantUML source from body.storage by position (Server format)."""
            storage_macros = self._storage_macros_by_name("plantuml")
            idx = self._plantuml_index
            self._plantuml_index += 1
            if idx >= len(storage_macros):
                return None
            plain_text_body = storage_macros[idx].find("plain-text-body")
            if not isinstance(plain_text_body, Tag):
                return None
            uml = plain_text_body.get_text(strip=True)
            return uml or None

        def convert_plantuml(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert PlantUML diagrams to Markdown code blocks.

            Supports two Confluence formats:

            1. **Cloud / editor2**: The editor2 XML contains structured macros with
               the UML definition in a JSON CDATA section (``{"umlDefinition": "..."}``).
               Each macro carries a ``macro-id`` that is also present in the view
               HTML as ``data-macro-id``.

            2. **Server / Data Center**: ``editor2`` is often empty.  The UML source
               lives as raw ``@startuml`` text inside ``<plain-text-body>`` CDATA
               sections in ``body.storage``.  The view HTML renders each diagram
               inside a ``<span data-macro-name="plantuml">`` without a ``macro-id``.
               Diagrams are matched by position (Nth diagram in storage corresponds
               to the Nth ``<span>`` in view HTML).
            """
            # Strategy 1: editor2 with macro-id (Cloud)
            macro_id = el.get("data-macro-id")
            if macro_id:
                uml = self._extract_uml_from_editor2(str(macro_id))
                if uml:
                    return f"\n```plantuml\n{uml}\n```\n\n"

            # Strategy 2: body.storage fallback (Server / Data Center)
            uml = self._extract_uml_from_storage()
            if uml:
                return f"\n```plantuml\n{uml}\n```\n\n"

            logger.warning("PlantUML macro could not be resolved from editor2 or body.storage")
            return "\n<!-- PlantUML diagram (source not found) -->\n\n"

        @staticmethod
        def _decode_plantumlcloud_data(data: str, *, compressed: bool) -> str | None:
            """Decode the ``data`` parameter of a ``plantumlcloud`` macro.

            The app stores the diagram source base64-encoded.  When ``compressed`` is
            set, the payload is additionally raw-deflated (no zlib header).  The text may
            also be percent-encoded, independently of ``compressed``, so that is detected
            from the text itself rather than from the parameter.

            Returns ``None`` on any malformed payload so the caller can emit a visible
            marker; never returns a partially decoded payload.
            """
            try:
                # Not `validate=True`: storage values may be line-wrapped, and rejecting
                # them here would discard a perfectly decodable diagram.
                payload = base64.b64decode(data)
            except ValueError:
                return None

            if compressed:
                decompressor = zlib.decompressobj(-zlib.MAX_WBITS)
                try:
                    payload = decompressor.decompress(payload, _MAX_PLANTUML_SOURCE_BYTES)
                except zlib.error:
                    return None
                # Not the size guard itself - `max_length` already bounds the inflate, and
                # the `eof` check below rejects what is left over. This branch only tells
                # "too large" apart from "truncated" in the log.
                if decompressor.unconsumed_tail:
                    logger.warning(
                        "PlantUML (plantumlcloud) source is larger than %d bytes, skipping it",
                        _MAX_PLANTUML_SOURCE_BYTES,
                    )
                    return None
                if not decompressor.eof:
                    # A truncated deflate stream inflates without error, so without this
                    # check a partial diagram would be exported as if it were complete.
                    logger.warning("PlantUML (plantumlcloud) payload is truncated, skipping it")
                    return None

            try:
                text = payload.decode("utf-8")
            except UnicodeDecodeError:
                return None

            # Percent-decode only when the payload actually is encoded: PlantUML sources
            # use a literal `%` (`%date%`, `%filename()`), which unquote would corrupt.
            if "@start" not in text:
                text = unquote(text)
            return text.strip() or None

        def _extract_uml_from_plantumlcloud(self, macro_id: str | None) -> str | None:
            """Extract PlantUML source for a `plantumlcloud` macro from body.storage."""
            macros = self._storage_macros_by_name("plantumlcloud")
            idx = (
                next((i for i, m in enumerate(macros) if m.get("macro-id") == macro_id), None)
                if macro_id
                else None
            )
            if idx is None:
                if macro_id and all(m.get("macro-id") for m in macros):
                    # Every stored macro is identifiable, yet none matches: the placeholder
                    # belongs to another page - an include macro expands the transcluded
                    # page's view HTML into this one. Falling back to position would emit
                    # an unrelated diagram, which is worse than none. Storage that carries
                    # no macro-id at all still falls through to positional matching.
                    return None
                idx = self._plantumlcloud_index
            if idx >= len(macros):
                return None
            # Advance the positional cursor past the consumed macro, also on a macro-id
            # match, so a later macro without a macro-id does not re-resolve this one.
            self._plantumlcloud_index = max(self._plantumlcloud_index, idx + 1)

            params = self._macro_params(macros[idx])
            data = params.get("data")
            if not data:
                return None
            compressed = params.get("compressed", "").lower() == "true"
            return self._decode_plantumlcloud_data(data, compressed=compressed)

        def convert_plantumlcloud(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            """Convert the `plantumlcloud` macro to a Markdown code block.

            The "Flowchart, PlantUML Diagrams for Confluence" app registers this macro
            name on Confluence Cloud.  Being a Connect app, it renders only an empty
            iframe placeholder into `body.view` and writes nothing to `editor2`, so the
            diagram source is recovered from `body.storage`, where it is kept in the
            macro's `data` parameter.
            """
            macro_id = el.get("data-macro-id")
            uml = self._extract_uml_from_plantumlcloud(str(macro_id) if macro_id else None)
            if uml:
                return f"\n```plantuml\n{uml}\n```\n\n"

            logger.warning("PlantUML (plantumlcloud) macro could not be resolved from body.storage")
            return "\n<!-- PlantUML diagram (source not found) -->\n\n"

        def convert_include(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert Confluence `include` / `excerpt-include` macro.

            When `include_macro = transclusion`, emit an Obsidian-style embed link
            (`![[Page Title]]`) so the referenced page renders inline in Obsidian,
            mimicking the Confluence include/excerpt behavior. Requires the target
            page to also be exported so the link can resolve.

            When `include_macro = inline` (default), the body_view content is
            already expanded — fall through to normal div processing to render it.
            """
            macro_name = str(el.get("data-macro-name", ""))
            macro_id = el.get("data-macro-id")

            target_title: str | None = None
            if macro_id and isinstance(macro_id, str):
                target_title = self._extract_include_target_title(macro_id)

            if settings.export.include_macro == "transclusion" and target_title:
                return f"\n![[{target_title}]]\n\n"

            if settings.export.include_macro == "transclusion":
                logger.warning(
                    f"{macro_name} macro found but target page title could not be resolved; "
                    f"falling back to inline content"
                )

            inline = super().convert_div(el, text, parent_tags)  # type: ignore[misc]
            if macro_name == "excerpt-include":
                title_note = f" from page '{target_title}'" if target_title else ""
                return (
                    f"\n<!-- excerpt start{title_note} -->\n"
                    f"{inline}"
                    f"\n<!-- excerpt end{title_note} -->\n\n"
                )
            return inline

        def _strip_excerpt_include_panel_titles(self, html: str) -> str:
            """Strip the source-page-title panel from `excerpt-include` bodies.

            Confluence's `excerpt-include` body.view wraps the included
            content in a panel whose `panelHeader` is the source page title
            unless `nopanel=true`. The `panelContent` div holds the actual
            body. We unwrap to leave only the body.
            """
            soup = BeautifulSoup(html, "html.parser")
            for el in soup.find_all(attrs={"data-macro-name": "excerpt-include"}):
                self._unwrap_excerpt_include_panel(el)
            return str(soup)

        def _unwrap_excerpt_include_panel(self, el: Tag) -> None:
            classes = el.get("class") or []
            if not isinstance(classes, list) or "panel" not in classes:
                return
            header = el.find("div", class_="panelHeader")
            if isinstance(header, Tag):
                header.decompose()
            content = el.find("div", class_="panelContent")
            if isinstance(content, Tag):
                content.unwrap()

        def _inline_app_macro_bodies(self, html: str) -> str:
            """Splice Connect app macro bodies back into the rendered view HTML.

            Confluence does not server-render the body of a Connect
            `dynamicContentMacros` app macro (e.g. the StiltSoft Table Filter) into
            body.view. It emits an empty `ap-container` placeholder and leaves the app
            to render the body in an iframe, so a Page Properties Report nested in such
            a macro never reaches `convert_table`. body.export_view does render the
            report, with the wrapper stripped, so the placeholder is replaced with that
            table and the regular report handling then applies unchanged.

            The two are matched on the CQL of the nested `detailssummary` macro in
            body.storage, because body.export_view carries no macro IDs.
            """
            if "ap-container" not in html:
                return html

            soup = BeautifulSoup(html, "html.parser")
            # `get_text` ignores <script>/<style> contents (BeautifulSoup models them as
            # Script/Stylesheet, which are excluded from the string traversal), so the
            # iframe bootstrap script the placeholder always carries does not count as
            # rendered content. Only a macro the app did not render server-side matches.
            placeholders = [
                el
                for el in soup.find_all("div", class_="ap-container")
                if isinstance(el, Tag)
                and el.get("data-hasbody") == "true"
                and not el.get_text(strip=True)
            ]
            if not placeholders:
                return html

            export_tables = self._export_report_tables_by_cql()
            for placeholder in placeholders:
                # An outer placeholder may have contained this one and been decomposed.
                if placeholder.parent is None:
                    continue
                macro_id = str(placeholder.get("data-macro-id", ""))
                cqls = self._nested_report_cqls(macro_id)
                if not cqls:
                    # Most app macros legitimately wrap no report, so this is not a
                    # warning; it is logged only to explain a placeholder left in place.
                    logger.debug(
                        f"App macro '{macro_id}' on page '{self.page.title}' "
                        f"(ID: {self.page.id}) has no nested Page Properties Report in "
                        f"body.storage; leaving the placeholder untouched."
                    )
                    continue
                tables = self._report_tables_for_cqls(cqls, export_tables, macro_id)
                if not tables:
                    continue
                for table in tables:
                    # Copy: the same table may be referenced by more than one placeholder,
                    # and inserting a live node moves it rather than duplicating it.
                    placeholder.insert_before(copy.copy(table))
                placeholder.decompose()
            return str(soup)

        def _report_tables_for_cqls(
            self, cqls: list[str], export_tables: dict[str, Tag], macro_id: str
        ) -> list[Tag]:
            """Resolve each nested report's CQL to its rendered body.export_view table."""
            tables: list[Tag] = []
            for cql in cqls:
                table = export_tables.get(_normalize_cql(cql))
                if table is None:
                    # The CQL itself is macro configuration and can embed labels or
                    # free-text filters, so it is kept out of the warning and logged
                    # only at debug level.
                    logger.warning(
                        f"Page Properties Report nested in app macro '{macro_id}' on page "
                        f"'{self.page.title}' (ID: {self.page.id}) has no matching table in "
                        f"body.export_view and is omitted from the export."
                    )
                    logger.debug(f"Unmatched Page Properties Report CQL: {cql}")
                    continue
                tables.append(table)
            return tables

        def _export_report_tables_by_cql(self) -> dict[str, Tag]:
            """Index the Page Properties Report tables rendered into body.export_view."""
            tables: dict[str, Tag] = {}
            soup = BeautifulSoup(self.page.body_export or "", "html.parser")
            for table in soup.find_all("table", class_="metadata-summary-macro"):
                cql = table.get("data-cql") if isinstance(table, Tag) else None
                if not isinstance(cql, str) or not cql:
                    continue
                key = _normalize_cql(cql)
                if key in tables:
                    logger.warning(
                        f"Page '{self.page.title}' (ID: {self.page.id}) has multiple Page "
                        f"Properties Reports with identical CQL; the first rendered table "
                        f"is used for all of them."
                    )
                    logger.debug(f"Duplicate Page Properties Report CQL: {key}")
                    continue
                tables[key] = table
            return tables

        @property
        def _storage_soup(self) -> BeautifulSoup:
            """Cache and return body.storage parsed for macro lookups.

            Parsed with `html.parser` rather than the `xml` parser used elsewhere:
            storage can contain HTML entities that are undefined in XML (third-party
            macros emit e.g. `&sbquo;`), which puts lxml into error recovery, where it
            silently drops unrelated entities such as the `&quot;` wrapping CQL values.
            That corrupts the CQL and breaks the report lookup. `html.parser` keeps the
            namespace prefixes, so both the prefixed and unprefixed tag names are
            accepted by the callers.
            """
            if self._storage_soup_cache is None:
                self._storage_soup_cache = BeautifulSoup(self.page.body_storage, "html.parser")
            return self._storage_soup_cache

        def _nested_report_cqls(self, macro_id: str) -> list[str]:
            """Return the CQL of each Page Properties Report nested in an app macro."""
            if not macro_id or not self.page.body_storage:
                return []

            for macro in self._storage_soup.find_all(_AC_MACRO_TAGS):
                if not isinstance(macro, Tag) or _ac_attr(macro, "macro-id") != macro_id:
                    continue
                cqls: list[str] = []
                for nested in macro.find_all(_AC_MACRO_TAGS):
                    if not isinstance(nested, Tag) or _ac_attr(nested, "name") != "detailssummary":
                        continue
                    for param in nested.find_all(_AC_PARAMETER_TAGS):
                        if isinstance(param, Tag) and _ac_attr(param, "name") == "cql":
                            cqls.append(param.get_text())
                            break
                return cqls
            return []

        def _extract_include_target_title(self, macro_id: str) -> str | None:
            """Resolve the target page title for an `include` / `excerpt-include` macro.

            BeautifulSoup with `xml` parser strips namespace prefixes, so
            `ac:structured-macro` becomes `structured-macro`, `ri:page` becomes
            `page`, and `ri:content-title` becomes `content-title`.
            """
            wrapped_editor2 = f"<root>{self.page.editor2}</root>"
            soup_editor2 = BeautifulSoup(wrapped_editor2, "xml")
            for macro in soup_editor2.find_all("structured-macro"):
                if not isinstance(macro, Tag):
                    continue
                if macro.get("name") not in ("include", "excerpt-include"):
                    continue
                if macro.get("macro-id") != macro_id:
                    continue
                ri_page = macro.find("page")
                if isinstance(ri_page, Tag):
                    title = ri_page.get("content-title")
                    if isinstance(title, str) and title:
                        return title
            return None

        def _find_element_with_namespace(self, parent: BeautifulSoup, tag_name: str) -> Tag | None:
            """Find an element with or without namespace prefix."""
            result = parent.find(f"ac:{tag_name}") or parent.find(tag_name)
            return result if isinstance(result, Tag) else None

        def _find_structured_macro(self, el: BeautifulSoup) -> Tag | None:
            """Find structured-macro element with or without namespace."""
            return self._find_element_with_namespace(el, "structured-macro")

        def _extract_plain_text_body(self, el: BeautifulSoup | Tag) -> str | None:
            """Extract markdown content from plain-text-body element."""
            plain_text_body = self._find_element_with_namespace(el, "plain-text-body")  # type: ignore[arg-type]
            if plain_text_body:
                return plain_text_body.get_text()
            return None

        def _extract_markdown_parameter(self, el: BeautifulSoup | Tag) -> str | None:
            """Extract markdown content from parameter element."""
            param = el.find("ac:parameter", {"ac:name": "markdown"})
            if param is None:
                param = el.find("parameter", {"name": "markdown"})
            if isinstance(param, Tag):
                return param.get_text()
            return None

        def _extract_markdown_from_body(self, el: BeautifulSoup) -> str | None:
            """Extract markdown content from body HTML."""
            # Try plain-text-body first (standard markdown macro)
            markdown_content = self._extract_plain_text_body(el)
            if markdown_content:
                return markdown_content

            # Check in structured-macro child element
            structured_macro = self._find_structured_macro(el)
            if structured_macro:
                markdown_content = self._extract_plain_text_body(structured_macro)
                if markdown_content:
                    return markdown_content

            # Try parameter for mohamicorp-markdown
            markdown_content = self._extract_markdown_parameter(el)
            if markdown_content:
                return markdown_content

            # Check parameter in structured-macro child
            if structured_macro:
                markdown_content = self._extract_markdown_parameter(structured_macro)
                if markdown_content:
                    return markdown_content

            return None

        def _extract_markdown_from_editor2(self, macro_id: str) -> str | None:
            """Extract markdown content from editor2 XML."""
            wrapped_editor2 = f"<root>{self.page.editor2}</root>"
            soup_editor2 = BeautifulSoup(wrapped_editor2, "xml")

            # BeautifulSoup strips namespace prefixes, so ac:structured-macro
            # becomes structured-macro
            markdown_macros = soup_editor2.find_all("structured-macro")
            for macro in markdown_macros:
                if not isinstance(macro, Tag):
                    continue
                if (
                    macro.get("name") in ("markdown", "mohamicorp-markdown")
                    and macro.get("macro-id") == macro_id
                ):
                    # Try plain-text-body first
                    plain_text_body = macro.find("plain-text-body")
                    if isinstance(plain_text_body, Tag):
                        return plain_text_body.get_text(strip=True)

                    # Try parameter for mohamicorp-markdown
                    param = macro.find("parameter", {"name": "markdown"})
                    if isinstance(param, Tag):
                        return param.get_text(strip=True)

            return None

        def convert_markdown(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            """Convert Markdown macro fragments to Markdown.

            Supports both standard 'markdown' macro and 'mohamicorp-markdown'
            macro. The content is already in Markdown format, so we just extract
            and return it.
            """
            macro_name = el.get("data-macro-name", "")

            # First, try to extract from body HTML
            markdown_content = self._extract_markdown_from_body(el)

            # If not found, try editor2 XML (similar to plantuml)
            if not markdown_content:
                macro_id = el.get("data-macro-id")
                if macro_id and isinstance(macro_id, str):
                    markdown_content = self._extract_markdown_from_editor2(macro_id)

            if not markdown_content:
                logger.warning(
                    f"Markdown macro ({macro_name}) found but no content could be extracted"
                )
                return f"\n<!-- Markdown macro ({macro_name}) content not found -->\n\n"

            # Return the markdown content directly (it's already in markdown format)
            # Add newlines for proper spacing
            return f"\n{markdown_content}\n\n"

        def convert_table(self, el: BeautifulSoup, text: str, parent_tags: list[str]) -> str:
            if el.has_attr("class") and "metadata-summary-macro" in el["class"]:
                return self.convert_page_properties_report(el, text, parent_tags)

            return super().convert_table(el, text, parent_tags)

        def convert_merged_table(self, el: BeautifulSoup, parent_tags: list[str]) -> str:
            """Preserve HTML links using the same destinations as Markdown links."""
            for link in el.find_all("a", href=True):
                destination_link = copy.copy(link)
                destination_link.attrs.pop("title", None)
                converted = self.convert_a(destination_link, link.get_text(), parent_tags)
                if destination := re.search(r".*\]\((.*)\)$", converted, re.DOTALL):
                    link["href"] = destination.group(1)
            return super().convert_merged_table(el, parent_tags)

        def convert_page_properties_report(
            self, el: BeautifulSoup, text: str, parent_tags: list[str]
        ) -> str:
            data_cql = el.get("data-cql")
            if not data_cql:
                return ""

            if settings.export.page_properties_report_format == "dataview":
                dql = self._cql_to_dataview(el, str(data_cql))
                if dql is not None:
                    return f"\n```dataview\n{dql}\n```\n"

            table: Tag | None = self._fetch_page_properties_report_table(el)
            if table is None:
                # Fall back to the server-rendered snapshot, which only contains
                # the first page of results (the macro's configured page size).
                soup = BeautifulSoup(self.page.body_export, "html.parser")
                table = cast("Tag | None", soup.find("table", {"data-cql": data_cql}))
            if table is None:
                return ""
            return super().convert_table(table, "", parent_tags)  # type: ignore -

        def _fetch_page_properties_report_table(self, el: BeautifulSoup) -> Tag | None:
            """Fetch all report rows via the masterdetail REST endpoint.

            The rendered table in ``body.export_view`` only contains the first
            page of results, so all rows are re-fetched through the endpoint the
            macro's own pagination uses. Returns None if the endpoint is
            unavailable, returns no or incomplete rows, or the macro has no
            explicit column configuration, so the caller can fall back to the
            rendered snapshot.
            """
            headings = str(el.get("data-headings", ""))
            if not headings.strip():
                # Without explicit columns the server derives the headings, so a
                # rebuilt header would not match the detail cells.
                return None
            url = "rest/masterdetail/1.0/detailssummary/lines"
            params: dict[str, Any] = {
                "cql": str(el.get("data-cql", "")),
                "spaceKey": str(el.get("data-current-space-key", "")),
                "headings": headings,
                "sortBy": str(el.get("data-sort-by", "")),
                "reverseSort": str(el.get("data-reverse-sort", "false")),
                "pageSize": _REPORT_FETCH_PAGE_SIZE,
                "pageIndex": 0,
            }
            lines: list[dict[str, Any]] = []
            try:
                client = get_thread_confluence(self.page.base_url)
                response = cast("dict", client.get(url, params=params))
                lines.extend(response.get("detailLines", []))
                total = int(response.get("total") or 0)
                total_pages = int(response.get("totalPages", 1))
                for page_index in range(1, total_pages):
                    response = cast(
                        "dict", client.get(url, params={**params, "pageIndex": page_index})
                    )
                    page_lines = response.get("detailLines", [])
                    if not page_lines:
                        break
                    lines.extend(page_lines)
                if total and len(lines) < total:
                    logger.warning(
                        f"Fetched only {len(lines)} of {total} Page Properties Report rows "
                        f"for page '{self.page.title}' (ID: {self.page.id}). "
                        f"Falling back to the rendered table snapshot."
                    )
                    return None
                if not lines:
                    return None
                return self._build_report_table(el, lines)
            except HTTPError as e:
                logger.warning(
                    f"Failed to fetch Page Properties Report rows for page "
                    f"'{self.page.title}' (ID: {self.page.id}): {e}. "
                    f"Falling back to the rendered table snapshot."
                )
                return None
            except Exception:  # noqa: BLE001
                logger.warning(
                    f"Unexpected error fetching Page Properties Report rows for page "
                    f"'{self.page.title}' (ID: {self.page.id}). "
                    f"Falling back to the rendered table snapshot.",
                    exc_info=True,
                )
                return None

        def _build_report_table(self, el: BeautifulSoup, lines: list[dict[str, Any]]) -> Tag | None:
            """Assemble a full HTML table from masterdetail detail lines."""
            first_col = str(el.get("data-first-column-heading") or "Title")
            headings = [h.strip() for h in str(el.get("data-headings", "")).split(",") if h.strip()]
            header = "".join(f"<th>{html.escape(h)}</th>" for h in [first_col, *headings])
            rows: list[str] = []
            for line in lines:
                title = html.escape(str(line.get("title") or ""))
                href = html.escape(str(line.get("relativeLink") or ""), quote=True)
                page_id = str(line.get("id") or "")
                if page_id.isdecimal():
                    link = (
                        f'<a href="{href}" data-linked-resource-type="page" '
                        f'data-linked-resource-id="{page_id}">{title}</a>'
                    )
                else:
                    # Without a numeric page id the link cannot be resolved to an
                    # exported page; keep the plain title text.
                    link = title
                # Detail cells are server-rendered HTML fragments; insert verbatim.
                cells = "".join(f"<td>{detail}</td>" for detail in line.get("details") or [])
                rows.append(f"<tr><td>{link}</td>{cells}</tr>")
            table_html = (
                f"<table><thead><tr>{header}</tr></thead><tbody>{''.join(rows)}</tbody></table>"
            )
            table = BeautifulSoup(table_html, "html.parser").find("table")
            return table if isinstance(table, Tag) else None

        def _cql_to_dataview(self, el: BeautifulSoup, cql: str) -> str | None:
            """Translate a Confluence CQL query to an Obsidian Dataview DQL query.

            Returns None if the CQL cannot be meaningfully translated.
            """
            current_content_id = str(el.get("data-current-content-id", ""))
            headings_raw = str(el.get("data-headings", ""))
            first_col = str(el.get("data-first-column-heading", "Title"))
            sort_by = str(el.get("data-sort-by", first_col))
            reverse_sort = str(el.get("data-reverse-sort", "false")).lower() == "true"

            label_conditions = [
                m.group(1) for m in re.finditer(r'label\s*=\s*"([^"]+)"', cql, re.IGNORECASE)
            ]

            parent_match = re.search(r'parent\s*=\s*"?(\d+)"?', cql, re.IGNORECASE)
            current_content_match = re.search(
                r"(?:ancestor|parent)\s*=\s*currentContent\s*\(\s*\)", cql, re.IGNORECASE
            )

            from_clause: str | None = None
            if current_content_match or (
                parent_match and parent_match.group(1) == current_content_id
            ):
                folder = str(self.page.export_path.parent).replace("\\", "/")
                from_clause = f'"{folder}"'

            if from_clause is None and not label_conditions:
                return None

            lines: list[str] = []

            if headings_raw:
                headings = [h.strip() for h in headings_raw.split(",") if h.strip()]
                col_names = ", ".join(f'{sanitize_key(h)} AS "{h}"' for h in headings)
                lines.append(f"TABLE {col_names}")
            else:
                lines.append("TABLE")

            from_parts = ([from_clause] if from_clause else []) + [
                f"#{lbl}" for lbl in label_conditions
            ]
            if from_parts:
                lines.append("FROM " + " AND ".join(from_parts))

            sort_col = sanitize_key(sort_by)
            sort_dir = "DESC" if reverse_sort else "ASC"
            lines.append(f"SORT {sort_col} {sort_dir}")

            return "\n".join(lines)

        def _get_path_for_href(
            self, path: Path, style: Literal["absolute", "relative", "wiki"]
        ) -> str:
            """Get the path to use in href attributes based on settings."""
            if style == "absolute":
                # Note that usually absolute would be
                # something like this: (settings.export.output_path / path).absolute()
                # In this case the URL will be "absolute" to the export path.
                # This is useful for local file links.
                result = "/" + str(path).lstrip("/")
            elif style == "wiki":
                result = path.name
            else:
                result = os.path.relpath(path, self.page.export_path.parent).replace(os.sep, "/")
            return result


_CQL_MAX_BATCH_SIZE: int = 25


def _fetch_page_ids_v2_batch(batch: list[str], base_url: str) -> set[str]:
    """Single v2 API request for a batch of page IDs.

    Uses GET /api/v2/pages?id=X&id=Y&...  (Atlassian Cloud).
    The v2 API accepts multiple ``id`` params, so they are encoded directly
    into the URL path since the SDK only accepts a dict for ``params``.
    """
    query = urllib.parse.urlencode([("id", pid) for pid in batch] + [("limit", len(batch))])
    response = cast("dict", get_thread_confluence(base_url).get(f"api/v2/pages?{query}"))
    if not response:
        return set()
    return {str(item["id"]) for item in response.get("results", [])}


def _fetch_page_ids_cql_batch(batch: list[str], base_url: str) -> set[str]:
    """Single CQL v1 request for a batch of page IDs.

    Uses GET /rest/api/content/search with id in (...) (self-hosted / fallback).
    """
    cql = "id in ({})".format(",".join(batch))
    response = cast(
        "dict",
        get_thread_confluence(base_url).get(
            "rest/api/content/search",
            params={"cql": cql, "limit": len(batch), "fields": "id"},
        ),
    )
    if not response:
        return set()
    return {str(item["id"]) for item in response.get("results", [])}


def fetch_deleted_page_ids(page_ids: list[str], base_url: str) -> set[str]:
    """Return the subset of *page_ids* that no longer exist in Confluence.

    Uses the v2 REST API when ``connection_config.use_v2_api`` is enabled
    (multiple ``id`` query params, up to ``export.existence_check_batch_size``
    IDs per request), or the v1 CQL content search otherwise (capped at
    :data:`_CQL_MAX_BATCH_SIZE` IDs per request).

    Per-batch API failures are handled safely: affected IDs are assumed to
    still exist so they are never accidentally deleted.
    """
    if not page_ids:
        return set()

    use_v2 = settings.connection_config.use_v2_api
    batch_size = settings.export.existence_check_batch_size
    effective_batch_size = batch_size if use_v2 else min(batch_size, _CQL_MAX_BATCH_SIZE)
    n_batches = -(-len(page_ids) // effective_batch_size)  # ceil division
    logger.debug(
        "Checking existence of %d page(s) in %d batch(es) via %s API",
        len(page_ids),
        n_batches,
        "v2" if use_v2 else "v1 CQL",
    )
    existing: set[str] = set()

    for i in range(0, len(page_ids), effective_batch_size):
        batch = page_ids[i : i + effective_batch_size]
        try:
            if use_v2:
                existing.update(_fetch_page_ids_v2_batch(batch, base_url))
            else:
                existing.update(_fetch_page_ids_cql_batch(batch, base_url))
        except Exception:  # noqa: BLE001
            logger.warning(
                "Failed to check page existence for batch (%d IDs). "
                "Skipping deletion for these pages.",
                len(batch),
            )
            existing.update(batch)

    return set(page_ids) - existing


def sync_removed_pages(base_url: str) -> None:
    """Orchestrate stale-file cleanup: check API for deleted pages, then clean up."""
    if not settings.export.cleanup_stale:
        logger.debug("Stale page cleanup disabled — skipping.")
        return

    # Renamed and moved pages are seen during the run, so they never show up as
    # unseen. Their old files still need removing, which needs no API call.
    deleted: set[str] = set()
    unseen = LockfileManager.unseen_ids()
    if unseen:
        with console.status(f"[dim]Checking {len(unseen)} unseen page(s) for removal…[/dim]"):
            deleted = fetch_deleted_page_ids(sorted(unseen), base_url)
        if deleted:
            logger.info("Removing %d stale page(s) from local export.", len(deleted))
    else:
        logger.debug("No unseen pages in lockfile — skipping existence check.")

    LockfileManager.remove_pages(deleted)


def _make_progress() -> Progress:
    """Build a rich Progress instance for page export."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
        transient=False,
    )


def _export_page_worker(page: "Page | Descendant", stats: ExportStats | None = None) -> None:
    """Export a single Confluence page to Markdown (worker function).

    Each page carries its own ``base_url`` so the correct thread-local client
    is used automatically — no global state manipulation needed.

    Args:
        page: The page to export.
        stats: Optional stats tracker to update on completion.
    """
    _page = Page.from_id(page.id, page.base_url)
    attachment_entries = _page.export()
    LockfileManager.record_page(_page, attachment_entries)
    if stats is not None:
        stats.inc_exported()


def export_pages(pages: list["Page | Descendant"]) -> None:
    """Export a list of Confluence pages to Markdown.

    Pages are exported in parallel using ThreadPoolExecutor for significant
    performance improvement. Worker count is read from
    settings.connection_config.max_workers (default: 20).

    Args:
        pages: List of pages to export.
    """
    # Mark all pages as seen so cleanup skips API checks for unchanged pages
    LockfileManager.mark_seen([p.id for p in pages])
    for p in pages:
        PageTitleRegistry.register(int(p.id), p.title)
    pages_to_export = [page for page in pages if LockfileManager.should_export(page)]

    skipped_count = len(pages) - len(pages_to_export)
    stats = reset_stats(total=len(pages))
    for _ in range(skipped_count):
        stats.inc_skipped()

    if skipped_count:
        logger.info("Skipping %d unchanged page(s).", skipped_count)

    if not pages_to_export:
        logger.info("All %d page(s) unchanged — nothing to export.", len(pages))
        return

    # Get worker count from config
    max_workers = settings.connection_config.max_workers
    serial = settings.export.log_level == "DEBUG" or max_workers <= 1

    mode_label = "serial" if serial else f"parallel ({max_workers} workers)"
    logger.debug("Export mode: %s, pages to export: %d", mode_label, len(pages_to_export))

    with _make_progress() as progress:
        task = progress.add_task(
            f"[cyan]Exporting {len(pages_to_export)} page(s)[/cyan]",
            total=len(pages_to_export),
        )

        if serial:
            for page in pages_to_export:
                progress.update(task, description=f"[cyan]Page {page.id}[/cyan]")
                try:
                    _export_page_worker(page, stats)
                except Exception:
                    logger.exception("Failed to export page %s", page.id)
                    stats.inc_failed()
                finally:
                    progress.advance(task)
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(_export_page_worker, page, stats): page
                    for page in pages_to_export
                }
                for future in as_completed(futures):
                    page = futures[future]
                    try:
                        future.result()
                    except Exception:
                        logger.exception("Failed to export page %s", page.id)
                        stats.inc_failed()
                    finally:
                        progress.advance(task)
