Fixture rendered
