# Confluence migration export report

Status: success

- Pages: 1
- Blocking errors: 0
- Warnings: 0
